from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
import urllib
import requests

class publikasi(models.Model):
  _name = 'cnt_pm.publikasi'
  _description = 'Kontraprestasi dalam bentuk Publikasi Rutin'
  _rec_name = 'mipro_id'

  mipro_id = fields.Many2one('cnt_pm.mipro')
  bentuk_kontraprestasi = fields.Char('Bentuk Kontraprestasi')
  rl = fields.Boolean('RL',default=True)
  web_internal = fields.Boolean('Web Internal',default=True)
  other_media = fields.Char('Media Lain')