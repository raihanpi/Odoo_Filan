import requests
import re
import urllib
import datetime
from odoo import models, api, fields

class NotifAccount(models.Model):
    _name = 'cnt_pm.notif_account'

    chat_id = fields.Char('Target ID')
    api_key = fields.Char('Api Key')
    active = fields.Boolean('Active',default=True)
    notif_via = fields.Selection([
        ('telegram', 'Telegram'),
        ('whatsapp', 'Whatsapp')
    ], string='Notif Via')
    url_web = fields.Char('Url Web')
    url_email = fields.Char('Url Mail')

    template_name_ids = fields.One2many('cnt_pm.template', 'notif_account_id', string='Template Name')

    html_regex = re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});')

