from odoo import api, fields, models
from odoo.exceptions import ValidationError

class Rab(models.Model):
    _name = 'cnt_pm.rab'
    _description = 'cnt_pm Rab'
    _rec_name = 'uraian'

    uraian = fields.Char(string='Uraian')
    no = fields.Integer(string='No')
    volume = fields.Integer(string='Volume')
    volume_qty = fields.Selection([
        ('paket', 'paket'),
        ('unit', 'unit'),
        ('orang', 'orang'),
        ('kamar', 'kamar'),
        ('lokasi', 'lokasi'),
        ('m', 'm'),
        ('m2', 'm2'),
    ], string='field_name')
    frekuensi = fields.Integer(string='Frekuensi')
    frekuensi_qty = fields.Selection([
        ('kali', 'kali'),
        ('hari', 'hari'),
        ('bulan', 'bulan'),
    ], string='frekuensi_qty')
    harga_satuan = fields.Float('Harga Satuan')
    total_baris = fields.Float('Total')
    sub_total = fields.Float('Sub Total')
    # proposal_id = fields.Many2one(comodel_name='cnt_pm.proposal', string='Proposal')
    # parent = fields.Integer(string='Parent')
    # children_from = fields.Integer(string='Children From')
    # order_child = fields.Integer(string='Order Child')
    # order_parent = fields.Integer(string='Order Parent')
