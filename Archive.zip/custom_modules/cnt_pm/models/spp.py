from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
import requests
import urllib

class SPP(models.Model):
    _name = 'cnt_pm.spp'
    _rec_name = 'nomor_spp'
    _description = 'SPP'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    
    
    nomor_spp = fields.Char(string='Nomor SPP')
    nomor_mipro = fields.Char(string='Nomor Mipro')
    nomor_proposal = fields.Char(string='Nomor Proposal')
    mipro_id = fields.Many2one(comodel_name='cnt_pm.mipro', string='Nama Program')
    proposal_id = fields.Many2one(comodel_name='cnt_pm.proposal', string='Proposal', tracking=True)
    rm_id = fields.Many2one(comodel_name='res.users', string='Nama Pengaju', required=True, tracking=True, default=lambda self: self.default_pengaju())
    partner_id = fields.Many2one(string='Nama Mitra', comodel_name='res.partner', tracking=True)
    rab_all = fields.Char(string='Rab All', tracking=True)
    mou_date = fields.Date(string='Tanggal Kesepakatan')
    approve_leader = fields.Boolean(string='Approve by PM Leader', tracking=True)
    approve_head = fields.Boolean(string='Approve by GMO', tracking=True)
    approve_rm = fields.Boolean(string='Approve by RM', tracking=True)
    start_implementation = fields.Date(string='Tanggal Dimulai Implementasi', tracking=True)
    end_implementation = fields.Date(string='Tanggal Berakhir Implementasi', tracking=True)
    proof = fields.Binary(string='Bukti transfer', help='Pilih foto disini', tracking=True)

    # otomatis nama pengaju berdasarkan yang login
    def default_pengaju(self):
        pengaju = self.env['res.users'].search([('user_ids.id', '=', self.env.user.id)])
        return pengaju
 
    # Data dari SPP diambil dari MIPRO 
    @api.onchange('mipro_id', 'proposal_id')
    def _onchange_mipro_and_proposal(self):
        if self.mipro_id:
            self.partner_id = self.mipro_id.partner_id
            self.start_implementation = self.mipro_id.start_implementation
            self.end_implementation = self.mipro_id.end_implementation
            self.provinsi_id = self.mipro_id.provinsi_id
            self.kota_id = self.mipro_id.kota_id
            self.kelurahan_id = self.mipro_id.kelurahan_id
            self.desa_id = self.mipro_id.desa_id
            self.nomor_mipro = self.mipro_id.nomor_mipro
            self.description_location = self.mipro_id.proposal_id.deskripsi_penyaluran
            self.KPI_project = self.mipro_id.kpi_project
            self.rab_all = self.mipro_id.rab_all 


        elif self.proposal_id:
        # Logika untuk mengisi nilai dari proposal ke spp
            self.nomor_proposal = self.proposal_id.nomor_proposal
            self.rab_all = self.proposal_id.rab_all
            self.partner_id = self.proposal_id.partner_id
            self.description_location = self.proposal_id.deskripsi_penyaluran
            self.nomor_mipro = self.proposal_id.mipro_ids.nomor_mipro
            self.price_donation = self.proposal_id.mipro_ids.donation_prediction
            self.vendor_name_id = self.proposal_id.mipro_ids.pelaksana
            self.start_implementation = self.proposal_id.mipro_ids.start_implementation
            self.end_implementation = self.proposal_id.mipro_ids.end_implementation
            self.provinsi_id = self.proposal_id.mipro_ids.provinsi_id
            self.kota_id = self.proposal_id.mipro_ids.kota_id
            self.kelurahan_id = self.proposal_id.mipro_ids.kelurahan_id
            self.desa_id = self.proposal_id.mipro_ids.desa_id
            self.KPI_project = self.proposal_id.mipro_ids.kpi_project
    
    # Informasi Donasi
    price_donation = fields.Float(size=15, digits=(15, 0), default=0, string='Nominal Donasi', readonly=False, tracking=True)

    # Pelaksanaan Program
    vendor_name_id = fields.Many2one('res.partner', string='Pelaksana Program', tracking=True)
    provinsi_id = fields.Many2one('cnt_pm.provinsi', string='Provinsi', tracking=True)
    kota_id = fields.Many2one('cnt_pm.kota', string='Kabupaten/Kota', tracking=True)
    kelurahan_id = fields.Many2one('cnt_pm.kecamatan', string='Kecamatan/Kelurahan', tracking=True)
    desa_id = fields.Many2one('cnt_pm.desa', string='Desa', tracking=True)
    description_location = fields.Text('Deskripsi Penyaluran', tracking=True)
    KPI_project = fields.Html('KPI Project', tracking=True)

    # Pengajuan Anggaran
    anggaranprogram_ids = fields.One2many(comodel_name='cnt_pm.anggaranprogram', inverse_name='spp_id')
    total = fields.Float(size=15, digits=(15, 0), default=0, string='Total', compute='_calculate_subtotal',  store=True)

    # Informasi Rekening
    info_rekening_id = fields.Many2one(comodel_name='cnt_pm.informasi_rekening', string='Atas Nama', tracking=True)
    @api.onchange('info_rekening_id')
    def set_informasi_rekening(self):
        self.account_number = self.info_rekening_id.account_number
        self.bank_name = self.info_rekening_id.bank_name

    account_number = fields.Char("Nomor Rekening")
    bank_name = fields.Char("Nama Bank")
    # Fields lainnya 
    managing_fund = fields.Integer(string='Dana Pengelola')
    management_fund_nominal = fields.Float(string='Nominal Dana Pengelola')
    dss_nominal = fields.Float(string='Nominal DSS', compute='_calculate_dss',  store=True)
    description_spp = fields.Text(string='Description')
    distribution_location = fields.Char('Lokasi Penyaluran')
    mil_id = fields.Many2one(comodel_name='cnt_pm.mil', string='Nomor MIL')
    program_name = fields.Char(string='Nama Program')
    log_message_ids = fields.One2many('cnt_pm.log', 'spp_id', string='Log Messages')
    vendor_bill_line_ids = fields.One2many('cnt_pm.anggaranprogram', 'module_id', string='Vendor Bill Lines')
    status_spp = fields.Selection([
        ('open', 'Open'),
        ('staffreplied', 'Process'),
        ('needreview', 'Need Review'),
        ('closed', 'Closed'),
        ('pending', 'Pending')
    ], default="open", string='Status', tracking=True)


    # Def otomatis nama pengaju
    def default_pengaju(self):
        pengaju = self.env['res.users'].search([('user_ids.id', '=', self.env.user.id)])
        return pengaju
    
    # ini buat total di pengajuan anggaran
    @api.depends('anggaranprogram_ids')
    def _calculate_subtotal(self):
        total = sum(record.subtotal for record in self.anggaranprogram_ids)
        self.total = total

    @api.model
    def create(self, vals):
        # create nomor SPP
        current_year = datetime.datetime.now().strftime("%Y")
        current_month = datetime.datetime.now().strftime("%m")
        month_mapping = {
            "01": "I",
            "02": "II",
            "03": "III",
            "04": "IV",
            "05": "V",
            "06": "VI",
            "07": "VII",
            "08": "VIII",
            "09": "IX",
            "10": "X",
            "11": "XI",
            "12": "XII",
        }
        current_month_roman = month_mapping[current_month]

        if not vals.get('nomor_spp'):
            nomor_spp = 'SPP'
            code_count = self.env['cnt_pm.spp'].search_count([('nomor_spp', 'like', nomor_spp + '%')])
            if code_count > 0:
                last_spp = self.env['cnt_pm.spp'].search([('nomor_spp', 'like', nomor_spp + '%')], order="id desc", limit=1)
                last_spp_number = int(last_spp.nomor_spp.split('.P')[-1].split('.')[0])
                nomor_spp += '.P' + str(last_spp_number + 1) + '.' + str(current_month_roman) + '.' + str(current_year)
            else:
                nomor_spp += '.P1.' + str(current_month_roman) + '.' + str(current_year)
            vals['nomor_spp'] = nomor_spp

        SPp = super(SPP, self).create(vals) 

        # Notif create proposal
        notif  = self.env['cnt_pm.spp'].search([('id', '=', SPp.id)])
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        current_user = self.env['res.users'].browse(self._uid)
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'spp_create_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(notif.partner_id.name))
            message = message.replace('<name_program>', str(notif.proposal_id.cover_title))
            message = message.replace('<rm_name_id>', str(notif.rm_id.name))
            message = message.replace('<file>', str(notif.rab_all))
            message = message.replace('<created_by>', str(current_user.name))
            message = message.replace('<id_spp>', str(SPp.id))
            self.send(message, urls)
    
        # # ini buat create cendor bills
        # SPp.create_vendor_bills()
        return SPp
    
    # def send buat notif
    def send (self, message, urls):
        urllib.parse.quote(message)
        url = "https://api.telegram.org/bot" + str(urls.api_key) + "/sendMessage?text=" + \
                message+"&chat_id="
        if urls.chat_id != False:
            try:
                requests.get(url + urls.chat_id)
            except requests.exceptions.ReadTimeout:
                print("TIMEOUT")
            pass
    
    # action buat reply
    def action_reply(self):
        self.ensure_one()
        return {
            'name': 'Reply Message',
            'type': 'ir.actions.act_window',
            'res_model': 'cnt_pm.reply',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
            'context': {
                'default_model': 'cnt_pm.spp',
                'default_res_id': self.id,
                'default_field': 'description_spp',
            },
        }
    
# definisiin buttons + notifikasi tiap buttons
    def pending_buttons(self):
        self.status_spp = 'pending'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'spp_pending_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<name_program>', str(self.mipro_id.proposal_id.cover_title))
            message = message.replace('<rm_name_id>', str(self.rm_id.name))
            message = message.replace('<id_spp>', str(self.id))
            # message = message.replace('<name>', str(self.name)) # sesuaikan dengan konten message
            self.send(message, urls)
    
    def close_buttons(self):
        self.status_spp = 'needreview'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'spp_review_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<name_program>', str(self.mipro_id.proposal_id.cover_title))
            message = message.replace('<rm_name_id>', str(self.rm_id.name))
            message = message.replace('<file>', str(self.rab_all))
            message = message.replace('<id_spp>', str(self.id))
            # message = message.replace('<name>', str(self.name)) # sesuaikan dengan konten message
            self.send(message, urls)

    def approve_buttons_ceo(self):
        self.status_spp = 'closed'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'spp_closed_notif_ceo')])
        current_user = self.env['res.users'].browse(self._uid)
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<name_program>', str(self.mipro_id.proposal_id.cover_title))
            message = message.replace('<rm_name_id>', str(self.rm_id.name))
            message = message.replace('<current_user>', str(current_user.name))
            message = message.replace('<file>', str(self.rab_all))
            message = message.replace('<id_spp>', str(self.id))
            # message = message.replace('<name>', str(self.name)) # sesuaikan dengan konten message
            self.send(message, urls)

    # Ini untuk autocraete e invoicing > vendors > bills
    # def create_vendor_bills(self):
    #     AccountMove = self.env['account.move']
    #     AccountMoveLine = self.env['account.move.line']
    #     target_model_product = self.env['product.template']
    #     BankAccount = self.env['res.partner.bank']
    #     for record in self:
    #         vals = {
    #             'partner_id': record.partner_id.id,
    #             'ref':record.nomor_spp,
    #             'invoice_date':fields.Date.today(),
    #             'invoice_date_due':record.end_implementation,
    #             'payment_reference':record.rm_id.name,
    #             'move_type': 'in_invoice',
    #         }
    #         account_move = AccountMove.sudo().create(vals)

    #         other_module_data = self.env['cnt_pm.anggaranprogram'].search([('spp_id', '=', record.id)])
    #         for datas in other_module_data:
    #             order_product = target_model_product.create({
    #                         'name': datas.product_name,
    #                         'list_price': datas.price,
    #                         'sale_ok':False,
    #                         'purchase_ok':True
    #                 })
    #         for data in other_module_data:
    #             line_vals = {
    #                 'product_id':order_product.id,
    #                 'move_id': account_move.id,
    #                 'name':data.label,
    #                 'quantity': data.qty,
    #                 'tax_ids': False,
    #                 'price_unit':order_product.list_price,
    #             }
    #             account_move_line = AccountMoveLine.create(line_vals)
    @api.constrains('anggaranprogram_ids')
    def _check_anggaranprogram_ids(self):
        print("CHECK HEULA", self.anggaranprogram_ids)
        if len(self.anggaranprogram_ids) < 1:
            print("TESTING R",self.anggaranprogram_ids)
            raise ValidationError("Pengajuan Anggaran Harus Terisi")



# Tab Pengajuan Anggaran
class AnggaranProgram(models.Model):
    _name = 'cnt_pm.anggaranprogram'
    _rec_name = 'program_name'
    _description = 'Informasi Program'

    program_name = fields.Char(string='Program Name')
    product_id = fields.Many2one('product.product', string='Program Name')
    product_name = fields.Char('Nama Produk')
    label = fields.Char('Label')
    qty = fields.Integer('Jumlah')
    price = fields.Float(size=15, digits=(15, 0), default=0, string='Harga Satuan')
    subtotal = fields.Float(size=15, digits=(15, 0), default=0, string='Subtotal', compute='_calculate_dss', store=True)
    spp_id = fields.Many2one(comodel_name='cnt_pm.spp')
    module_id = fields.Many2one('cnt_pm.spp', string='Module')

    @api.depends("qty", "price")
    def _calculate_dss(self):
        for r in self:
            r.subtotal = r.qty * r.price
    
# class AccountMove(models.Model):
#     _inherit = 'account.move'

#     @api.model
#     def action_post(self):
#         res = super(AccountMove, self).action_post()

#         my_module_records = self.env['cnt_pm.spp'].search([])  # Retrieve all records of your custom module

#         for record in my_module_records:
#             if record.vendor_bills:
#                 for bill in record.vendor_bills:
#                     if bill.state == 'posted' and not bill.bill_number:
#                         bill.write({'bill_number': bill.name})

#         return res
