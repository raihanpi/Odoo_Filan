from odoo import api, fields, models
from odoo.exceptions import ValidationError

class RencanaProject(models.Model):
    _name = 'cnt_pm.rencanaproject'
    _description = 'cnt_pm Rencana Project'
    _rec_name = 'cover_title'

    cover_title = fields.Char(string='Program Ajuan')
    project_location = fields.Char(string='Lokasi Project') 
    mip_id = fields.Many2one(string='MIP', comodel_name='cnt_pm.mip') 
    status = fields.Selection([
        ('pending','Pending'),
        ('approve', 'Approve'),
        ('decline', 'Decline'),
    ], default='pending',string='Status')
    note = fields.Char(string='Catatan')
    donation_prediction = fields.Char(string='Prediksi Donasi')
    
    @api.model
    def write(self, values):
        if 'status' in values and values.get('status') in ['approve', 'Approve']:
            if self.status != values['status']:
                data = {
                    'cover_title': self.cover_title,
                    'plan_lokasi': self.project_location,
                    'partner_id': self.mip_id.pengaju_name.id,
                    'rm_name_id': self.mip_id.pengaju_name.id
                }
                self.env['cnt_pm.proposal'].create(data)
        return super(RencanaProject, self).write(values)
