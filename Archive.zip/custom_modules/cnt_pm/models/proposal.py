from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
import requests
import urllib
import json
import pathlib
from google.cloud import storage
from google.oauth2 import service_account
import tempfile
import os
import base64
from pydrive.drive import GoogleDrive
from pydrive.auth import GoogleAuth

class Proposal(models.Model):
    _name = 'cnt_pm.proposal'
    _description = 'Proposal'
    _rec_name = 'cover_title'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    mipro_ids = fields.One2many(comodel_name='cnt_pm.mipro', inverse_name='proposal_id', string='Mipro')
    mil_ids = fields.One2many(comodel_name='cnt_pm.mil', inverse_name='proposal_id', string='Mil')
    nomor_proposal = fields.Char('Nomor Proposal')    
    description_proposal = fields.Text(string='Description')
    log_message_ids = fields.One2many('cnt_pm.log', 'proposal_id', string='Log Messages')
    cover_title = fields.Char(string='Nama Program',required=True, tracking=True)
    mip_id = fields.Many2one(comodel_name='cnt_pm.mip', string='MIP')
    partner_id = fields.Many2one(comodel_name='res.partner', string='Deskripsi Nama Mitra', tracking=True)
    rm_name_id = fields.Many2one(comodel_name='res.users', string='Nama RM', required=True, default=lambda self: self.default_pengaju())
    donation_prediction = fields.Float(size=15, digits=(15, 0), default=0, string='Perkiraan Donasi', tracking=True)
    deadline = fields.Date('Due Date', related='mip_id.deadline', readonly=True, store=True)
    assignee_id = fields.Many2one(comodel_name='res.users', string='Nama PD', tracking=True)
    is_gmo_revision = fields.Integer(string="Revisi GMO", default=0)
    is_reviewed = fields.Integer(string="Sudah Di Review RM", default=0)

    def default_pd(self):
        rm = self.env['cnt_pm.relasi'].search([('rm_id.id', '=', self.env.user.id)])
        print('INI RM nya ada',rm,'INI PD NYA ADA',rm.pd_id.id)
        return rm.pd_id.id
    

    # Dokumen Proposal
    dokumenproposal_ids = fields.One2many(comodel_name='cnt_pm.dokumenproposal', inverse_name='proposal_id')

    note = fields.Text(string='Note')
    log_note = fields.Text(string='Log Note')
    draft = fields.Char(string='File',placeholder='Tempelkan url disini')
    tanggal_kirim = fields.Datetime(string='Tanggal Kirim')
    # rm_ids = fields.Many2many(comodel_name='res.users', string='rm')
    createdBy_id = fields.Many2one(comodel_name='res.users', string='RM')
    note = fields.Char(string='Catatan')

    # SPP
    spp_ids = fields.One2many(comodel_name='cnt_pm.spp', inverse_name='proposal_id')
    

    # COVER
    # cover_number_proposal = fields.One2many('cnt_pm.mipro','informasi_pengaju_proposal_number',string='Nomer Proposal')
    patner_name= fields.One2many(comodel_name='cnt_pm.mil',inverse_name='mil_partner_name', string='patner Name')
    cover_logo_mitra = fields.Binary(string='Cover Logo Mitra')
    cover_background = fields.Binary(string='Cover Proposal')
    cover_namaprogram = fields.Char('Judul Proposal')
    agreement_donation = fields.Float(string='Kesepakatan Donasi')
    mipro_id = fields.Many2one(comodel_name='cnt_pm.mipro', string='Nama Program')

    # DESKRPSI
    deskripsi_namaprogram = fields.Char('Deskripsi Nama Program')
    deskripsi_penyaluran = fields.Text('Deskripsi Penyaluran', tracking=True)
    rab_all = fields.Char(string='Rab All', tracking=True)
    mou = fields.Char('MOU')

    plan_lokasi = fields.Char('Lokasi Implementasi', tracking=True)
    plan_sasaran = fields.Html('Sasaran')
    
    file = fields.Binary('File')
    note_file = fields.Binary('Note File')

    status = fields.Selection([
        ('1_open', 'Open'),
        ('2_staffreplied', 'Staff Replied'),
        ('3_needreview', 'Need Review'),
        ('4_closed', 'Closed'),
        ('5_pending', 'Pending')
    ], default="1_open", string='Status', tracking=True)
    # #ini untuk status MIP

    #buat status untuk proposal agar saat reply tidak bentrok dengan status mip
    status_proposal = fields.Selection([
        ('1_open', 'Open'),
        ('2_staffreplied', 'Revision'),
        ('3_needreview', 'Need Review RM'),
        ('3_2_needreview_gmo', 'Need Review GMO'),
        ('4_closed', 'Approved'),
        ('5_closed', 'Closed'),
        ('pending', 'Pending')
    ], default="1_open", string='Status', tracking=True)

    # Actions
    def action_show_log_note(self):
        self.ensure_one()
        self.message_post(body=self.log_note)

    def action_save_note(self):
        self.ensure_one()
        self.log_note = self.note
        self.note = ''
        if self.log_note:
            self.message_post(body=self.log_note)

    def action_cancel_note(self):
        self.ensure_one()
        self.note = ''
    
    def default_pengaju(self):
        pengaju = self.env['res.users'].search([('user_ids.id', '=', self.env.user.id)])
        return pengaju

    # Onchange
    @api.onchange('mip_id')
    def set_nama_program(self):
        self.deadline = self.mip_id.deadline
        
    @api.onchange('cover_title', 'mip_id')
    def _onchangenamamitra(self):
        if self.mip_id and self.mip_id.partner_id:
            self.partner_id = self.mip_id.partner_id.id
        else:
            self.partner_id = False
        if self.mip_id and self.mip_id.assignee_id:
            self.assignee_id = self.mip_id.assignee_id.id
        else:
            self.assignee_id = False

    @api.constrains('mip_id')
    def getMIP(self):
        self.rm_name_id = self.mip_id.rm_name_id
        self.partner_id = self.mip_id.partner_id

    # crete proposal number
    @api.model
    def create(self, vals):
        # Get current year and month
        current_year = datetime.datetime.now().strftime("%Y")
        current_month = datetime.datetime.now().strftime("%m")
        month_mapping = {
            "01": "I",
            "02": "II",
            "03": "III",
            "04": "IV",
            "05": "V",
            "06": "VI",
            "07": "VII",
            "08": "VIII",
            "09": "IX",
            "10": "X",
            "11": "XI",
            "12": "XII",
        }
        
        current_month_roman = month_mapping[current_month]
        if not vals.get('nomor_proposal'):
                nomor_proposal = 'PMS'
                code_count = self.env['cnt_pm.proposal'].search_count([('nomor_proposal', 'like', nomor_proposal + '%')])
                if code_count > 0:
                    last_proposal = self.env['cnt_pm.proposal'].search([('nomor_proposal', 'like', nomor_proposal + '%')], order="id desc", limit=1)
                    last_proposal_number = int(last_proposal.nomor_proposal.split('.P')[-1].split('.')[0])
                    nomor_proposal += '.P' + str(last_proposal_number + 1) + '.' + str(current_month_roman) + '.' + str(current_year)
                else:
                    nomor_proposal += '.P1.' + str(current_month_roman) + '.' + str(current_year)
                vals['nomor_proposal'] = nomor_proposal

        proposal = super(Proposal, self).create(vals)

        # Notif create proposal
        notif  = self.env['cnt_pm.proposal'].search([('id', '=', proposal.id)])
        current_user = self.env['res.users'].browse(self._uid)
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'proposal_create_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<name_program>', str(notif.cover_title))
            message = message.replace('<partner_id>', str(notif.partner_id.name))
            message = message.replace('<rm_name_id>', str(notif.rm_name_id.name))
            message = message.replace('<file>', str(notif.rab_all))
            message = message.replace('<created_by>', str(current_user.name))
            message = message.replace('<id_proposal>', str(proposal.id))
            message = message.replace('<id_pd>', str(notif.assignee_id.name))
            self.send(message, urls)
    
        return proposal

    # API Telegram
    def send (self, message, urls):
        urllib.parse.quote(message)
        url = "https://api.telegram.org/bot" + str(urls.api_key) + "/sendMessage?text=" + \
                message+"&chat_id="
        if urls.chat_id != False:
            try:
                requests.get(url + urls.chat_id)
            except requests.exceptions.ReadTimeout:
                print("TIMEOUT")
            pass
    
    #Action Reply
    def action_reply(self):
        self.ensure_one()
        return {
            'name': 'Reply Message',
            'type': 'ir.actions.act_window',
            'res_model': 'cnt_pm.reply',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
            'context': {
                'default_model': 'cnt_pm.proposal',
                'default_res_id': self.id,
                'default_field': 'description_proposal',
            },
        }

    # Notif Pedding
    def pending_buttons(self):
        self.status_proposal = 'pending'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'proposal_pending_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<name_program>', str(self.cover_title))
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<rm_name_id>', str(self.rm_name_id.name))
            message = message.replace('<id_proposal>', str(self.id))
            message = message.replace('<id_pd>', str(self.assignee_id.name))
            self.send(message, urls)

    # notif Closed
    def close_buttons(self):
        self.status_proposal = '3_needreview'
        self.is_reviewed = 1
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'proposal_review_notif')])
        current_user = self.env['res.users'].browse(self._uid)
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<name_program>', str(self.cover_title))
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<rm_name_id>', str(self.rm_name_id.name))
            message = message.replace('<current_user>', str(current_user.name))
            message = message.replace('<file>', str(self.rab_all))
            message = message.replace('<id_proposal>', str(self.id))
            message = message.replace('<id_pd>', str(self.assignee_id.name))
            self.send(message, urls)
        # notif Closed

    def close_buttons_gmo(self):
        self.status_proposal = '3_2_needreview_gmo'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'proposal_review_notif_gmo')])
        current_user = self.env['res.users'].browse(self._uid)
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<name_program>', str(self.cover_title))
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<rm_name_id>', str(self.rm_name_id.name))
            message = message.replace('<current_user>', str(current_user.name))
            message = message.replace('<file>', str(self.rab_all))
            message = message.replace('<id_proposal>', str(self.id))
            message = message.replace('<id_pd>', str(self.assignee_id.name))
            self.send(message, urls)

    # Notif Approve
    def approve_buttons(self):
        self.status_proposal = '4_closed'
        self.is_gmo_revision = 1
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'proposal_closed_notif')])
        current_user = self.env['res.users'].browse(self._uid)
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<name_program>', str(self.cover_title))
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<rm_name_id>', str(self.rm_name_id.name))
            message = message.replace('<current_user>', str(current_user.name))
            message = message.replace('<file>', str(self.rab_all))
            message = message.replace('<id_proposal>', str(self.id))
            message = message.replace('<id_pd>', str(self.assignee_id.name))
            self.send(message, urls)
    
    def mitra_closed_buttons(self):
        mipro = self.env['cnt_pm.mipro'].search([('nomor_proposal','=',self.nomor_proposal)])
        print(self.nomor_proposal)
        print(mipro.nomor_proposal)
        if mipro.nomor_proposal != self.nomor_proposal:
            raise ValidationError("Proposal tidak bisa di-close karena proposal belum ada di mipro")
        else:
            self.status_proposal = '5_closed'
            urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
            template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'proposal_closed_mitra_notif')])
            current_user = self.env['res.users'].browse(self._uid)
            if urls.notif_via == 'telegram':
                message = template_telegram.template_content
                message = message.replace('<name_program>', str(self.cover_title))
                message = message.replace('<partner_id>', str(self.partner_id.name))
                message = message.replace('<rm_name_id>', str(self.rm_name_id.name))
                message = message.replace('<current_user>', str(current_user.name))
                message = message.replace('<file>', str(self.rab_all))
                message = message.replace('<id_proposal>', str(self.id))
                message = message.replace('<id_pd>', str(self.assignee_id.name))
                self.send(message, urls)
    
    def kanban_color(self, status_proposal):
        # Define the color mapping based on the status field
        color_mapping = {
            '1_open': 'kanban-color-grey',
            '2_staffreplied': 'kanban-color-yellow',
            '4_closed': 'kanban-color-green'
        }
        return color_mapping.get(status_proposal, '')
    
    #validasi 2 nama program di proposal
    @api.constrains('partner_id','cover_title')
    def _check_duplicate_proposal(self):
        for record in self:
            duplicate_records = self.search([
                ('cover_title', 'ilike', record.cover_title),
                ('partner_id', '=', record.partner_id.id),
                ('id', '!=', record.id),  # Exclude the current record from the search
            ])
            if duplicate_records:
                error_message = (
                    f"Program ('{record.cover_title}') "
                    f"Sudah ada pada mitra ('{record.partner_id.name}')."
                )
                raise ValidationError(error_message)

    # Ini untuk otomatis 
    # def write(self, vals):
    #     status_before_edit=self.status_proposal
    #     res = super(Proposal, self).write(vals)
        
    #     # Periksa status proposal = closed
    #     if 'status_proposal' in vals and vals['status_proposal'] == '4_closed' and status_before_edit != '4_closed':
    #         target_model = self.env['cnt_pm.mipro']
    #         target_model_product = self.env['product.template']

    #         for proposal in self:
    #             no_proposal = str(proposal.nomor_proposal)
    #             partner = int(proposal.partner_id)
    #             rm = int(proposal.rm_name_id)

    #             if proposal.partner_id:
    #                 # Handling proposal sebelum nge create MIPRO 
    #                 existing_mipro = target_model.search([('proposal_id', '=', proposal.id)])
    #                 if not existing_mipro:
    #                     # Jika data belum ada di Mipro, lakukan autocreate
    #                     target_model.create({
    #                         'proposal_id': proposal.id,
    #                         'rm_id': rm,
    #                         'partner_id': partner,
    #                         'program_name': proposal.cover_title,
    #                         'nomor_mou': proposal.mou,
    #                         'nomor_proposal':proposal.nomor_proposal,
    #                         'rab_all':proposal.rab_all,
    #                         'donation_prediction':proposal.donation_prediction,
    #                         'deskripsi_penyaluran':proposal.deskripsi_penyaluran,
    #                         'status_proposal':proposal.status_proposal
    #                     })
    #             if proposal.partner_id:
    #                 target_model_product.create({
    #                     'name': proposal.cover_title,
    #                     'list_price': proposal.agreement_donation
    #                 })
    #     return res
    # @api.constrains('dokumenproposal_ids')
    # def _check_dokumenproposal_ids(self):
    #     print("CHECK HEULA", self.dokumenproposal_ids)
    #     if len(self.dokumenproposal_ids) < 1:
    #         print("TESTING R",self.dokumenproposal_ids)
    #         raise ValidationError("Dokumen Proposal minimal harus ada 1 (satu)")
  
class DokumenProposal(models.Model):
    _name = 'cnt_pm.dokumenproposal'
    _description = 'Dokumen Proposal'
    _rec_name = 'proposal_id'

    proposal_id = fields.Many2one('cnt_pm.proposal')
    jenis_dokumen = fields.Selection([
        ('proposal', 'Proposal'),
        ('rab_mitra', 'RAB Mitra'),
        ('ppt', 'PPT'),
    ], string='Jenis Dokumen', tracking=True)

    note = fields.Text('Catatan', tracking=True)
    file = fields.Text(string='File Pendukung', tracking=True)
    file_upload = fields.Binary(string='File Test', tracking=True)

    file_notulensi = fields.Text('File Notulensi', tracking=True)
    file_notulensi_upload = fields.Binary(string='File Notulensi Test', tracking=True)
    status = fields.Selection([
        ('1_open', 'Open'),
        ('4_closed', 'Closed')
    ], default="1_open", string='Status', tracking=True)
    deadline = fields.Date('Due Date')

    
    def login(self):
        # Below code does the authentication
        # part of the code
        gauth = GoogleAuth()

        # Try to load saved client credentials
        gauth.LoadCredentialsFile("mycreds.txt")
        print(gauth.credentials)
        if gauth.credentials is None:
            # Authenticate if they're not there
            print("MASUK KESINI")
            gauth.LocalWebserverAuth()
        elif gauth.access_token_expired:
            # Refresh them if expired
            print("MASUK KE REFRESH")
            gauth.Refresh()
        else:
            # Initialize the saved creds
            gauth.Authorize()
        gauth.SaveCredentialsFile("mycreds.txt")
        drive = GoogleDrive(gauth)

        return gauth, drive

    def createFolder(self, drive, folderName, parent_id=None):
        metadata = {
            'title': folderName,
            "mimeType": "application/vnd.google-apps.folder"
        }

        if parent_id:
            metadata['parents'] = [{'id': parent_id}]

        result = drive.CreateFile(metadata)
        result.Upload(param={'supportsTeamDrives': True})

        new_permission = {
            'id': 'anyoneWithLink',
            'type': 'anyone',
            'value': 'anyoneWithLink',
            'withLink': True,
            'role': 'reader'
        }

        result.auth.service.permissions().insert(
            fileId=result['id'], body=new_permission, supportsTeamDrives=True).execute(http=result.http)

        return result['id']

    def getFolderID(self, drive, folderName, parent_id=None):
        if parent_id:
            folders = drive.ListFile(
                {'q': "title='" + folderName + "' and '"+parent_id+"' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false"}).GetList()
        else:
            folders = drive.ListFile(
                {'q': "title='" + folderName + "' and mimeType='application/vnd.google-apps.folder' and trashed=false"}).GetList()
        for folder in folders:
            if folder['title'] == folderName:
                return folder['id']

        # If not exist create it
        return self.createFolder(drive, folderName, parent_id)

    def uploadImageFromString(self, gauth, folder_id, filename, string):
        metadata = {
            "name": filename,
            "parents": [folder_id]
        }

        files = {
            'data': ('metadata', json.dumps(metadata), 'application/json'),
            'file': base64.b64decode(
                string)
        }
        r = requests.post(
            "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
            headers={"Authorization": "Bearer " +
                     gauth.credentials.access_token},
            files=files
        )
        result = r.json()
        return "https://drive.google.com/uc?id=" + result['id']

    @api.model
    def create(self, values):
        if 'file_upload' in values:
            gauth, drive = self.login()
            user = self.env['res.users'].search(
                [('id', '=', self.env.user.id)])
            parent_parent_parent_name = "FIS"
            parent_parent_name = "Dokumen Proposal"
            parent_name = user.name
            folder_name = "Proposal"
            parent_parent_parent_id = self.getFolderID(drive, parent_parent_parent_name)
            parent_parent_id = self.getFolderID(drive, parent_parent_name, parent_id=parent_parent_parent_id)
            parent_id = self.getFolderID(drive, parent_name, parent_id=parent_parent_id)
            folder_id = self.getFolderID(drive, folder_name, parent_id=parent_id)
            proposal_name = self.env['cnt_pm.proposal'].search([('id', '=', values['proposal_id'])])
            partner_name = self.env['res.partner'].search([('id', '=', proposal_name.rm_name_id.id)])


                
            now = datetime.datetime.now()
            filename = "Proposal_" + str(proposal_name.rm_name_id.name)+ "_" + str(proposal_name.cover_title) + "_" + str(now.strftime('%d')) + "_"  + str(now.strftime('%B')) + "_" + str(now.strftime('%Y'))
            if values['file_upload'] == False:
                values['file'] = False
                values['file_upload'] = False
            else:
                values['file'] = self.uploadImageFromString(
                        gauth, folder_id, filename, values['file_upload'])
                values['file_upload'] = False
                # values['filename'] = filename
        

        if 'file_notulensi_upload' in values:
            gauth, drive = self.login()
            user = self.env['res.users'].search(
                [('id', '=', self.env.user.id)])
            parent_parent_parent_name = "FIS"
            parent_parent_name = "Dokumen Proposal"
            parent_name = user.name
            folder_name = "Notulensi"
            parent_parent_parent_id = self.getFolderID(drive, parent_parent_parent_name)
            parent_parent_id = self.getFolderID(drive, parent_parent_name, parent_id=parent_parent_parent_id)
            parent_id = self.getFolderID(drive, parent_name, parent_id=parent_parent_id)
            folder_id = self.getFolderID(drive, folder_name, parent_id=parent_id)
            proposal_name = self.env['cnt_pm.proposal'].search([('id', '=', values['proposal_id'])])
            partner_name = self.env['res.partner'].search([('id', '=', proposal_name.rm_name_id.id)])


                
            now = datetime.datetime.now()
            filename = "Notulensi_" + str(proposal_name.rm_name_id.name)+ "_" + str(proposal_name.cover_title) + "_" + str(now.strftime('%d')) + "_"  + str(now.strftime('%B')) + "_" + str(now.strftime('%Y'))
            if values['file_notulensi_upload'] == False:
                values['file_notulensi'] = False
                values['file_notulensi_upload'] = False
            else:
                values['file_notulensi'] = self.uploadImageFromString(
                        gauth, folder_id, filename, values['file_notulensi_upload'])
                values['file_notulensi_upload'] = False
                # values['filename'] = filename

        

        res = super(DokumenProposal, self).create(values)

        return res

    def write(self, values):
        if 'file_upload' in values:
            gauth, drive = self.login()
            user = self.env['res.users'].search(
                [('id', '=', self.env.user.id)])
            parent_parent_parent_name = "FIS"
            parent_parent_name = "Dokumen Proposal"
            parent_name = user.name
            folder_name = "Proposal"
            parent_parent_parent_id = self.getFolderID(drive, parent_parent_parent_name)
            parent_parent_id = self.getFolderID(drive, parent_parent_name, parent_id=parent_parent_parent_id)
            parent_id = self.getFolderID(drive, parent_name, parent_id=parent_parent_id)
            folder_id = self.getFolderID(drive, folder_name, parent_id=parent_id)
            proposal_name = self.env['cnt_pm.proposal'].search([('id', '=', self.proposal_id.id)])
            partner_name = self.env['res.partner'].search([('id', '=', proposal_name.rm_name_id.id)])


                
            now = datetime.datetime.now()
            filename = "Proposal_" + str(proposal_name.rm_name_id.name)+ "_" + str(proposal_name.cover_title) + "_" + str(now.strftime('%d')) + "_"  + str(now.strftime('%B')) + "_" + str(now.strftime('%Y'))
            if 'file_upload' == False:
                values['file'] = False
                values['file_upload'] = False
                # values['filename'] = filename
            else:
                values['file'] = self.uploadImageFromString(
                        gauth, folder_id, filename, values['file_upload'])
                values['file_upload'] = False
        

        if 'file_notulensi_upload' in values:
            gauth, drive = self.login()
            user = self.env['res.users'].search(
                [('id', '=', self.env.user.id)])
            parent_parent_parent_name = "FIS"
            parent_parent_name = "Dokumen Proposal"
            parent_name = user.name
            folder_name = "Notulensi"
            parent_parent_parent_id = self.getFolderID(drive, parent_parent_parent_name)
            parent_parent_id = self.getFolderID(drive, parent_parent_name, parent_id=parent_parent_parent_id)
            parent_id = self.getFolderID(drive, parent_name, parent_id=parent_parent_id)
            folder_id = self.getFolderID(drive, folder_name, parent_id=parent_id)
            proposal_name = self.env['cnt_pm.proposal'].search([('id', '=', self.proposal_id.id)])
            partner_name = self.env['res.partner'].search([('id', '=', proposal_name.rm_name_id.id)])


                
            now = datetime.datetime.now()
            filename = "Notulensi_" + str(proposal_name.rm_name_id.name)+ "_" + str(proposal_name.cover_title) + "_" + str(now.strftime('%d')) + "_"  + str(now.strftime('%B')) + "_" + str(now.strftime('%Y'))
            if 'file_notulensi_upload' == False:
                values['file_notulensi'] = False
                values['file_notulensi_upload'] = False
            else:
                values['file_notulensi'] = self.uploadImageFromString(
                        gauth, folder_id, filename, values['file_notulensi_upload'])
                values['file_notulensi_upload'] = False
        

        # if vals['status_mil'] == '4_closed' and self.mil_agreement_donation == 0:
        #     raise ValidationError('Kesepakatan donasi tidak boleh nol!!!')
        res = super(DokumenProposal, self).write(values)