from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
import urllib
import requests

class bentukLaporan(models.Model):
  _name = 'cnt_pm.bentuk_laporan'
  _description = 'Bentuk Laporan'
  _rec_name = 'mipro_id'

  mipro_id = fields.Many2one('cnt_pm.mipro')
  report_name = fields.Char('Bentuk Laporan')
  deadline_report = fields.Text('Deadline')
  ket_report = fields.Text('Keterangan')