from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
import urllib
import requests

class informasiRekening(models.Model):
  _name = 'cnt_pm.informasi_rekening'
  _description = 'informasi_rekening'
  _rec_name = 'user_bank'


  bank_name = fields.Char('Nama Bank')
  account_number = fields.Char('Nomor Rekening')
  user_bank = fields.Char(string='Atas Nama')
