from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
import urllib
import requests

class Timeline(models.Model):
  _name = 'cnt_pm.timeline'
  _description = 'Timeline Mipro'
  _rec_name = 'mipro_id'

  mipro_id = fields.Many2one('cnt_pm.mipro')
  aktivitas = fields.Text('Aktivitas')
  start_implementasi = fields.Date(string='Start')
  end_implementasi = fields.Date(string='Finish')