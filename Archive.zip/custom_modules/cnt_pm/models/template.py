from odoo import models, fields


class Template(models.Model):
    _name = 'cnt_pm.template'

    id_template = fields.Char('ID Template')
    template_content = fields.Text('Template Content')
    active = fields.Boolean('Active', default=True)
    notif_account_id = fields.Many2one('cnt_pm.notif_account', string='Notif Account ID')
