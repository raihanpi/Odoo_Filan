from odoo import models, fields, api # Mandatory


class Log(models.Model):
    _name = 'cnt_pm.log'
    _description = 'PM: Log'

    message = fields.Text(string='Message')
    model = fields.Char(string='Model')
    res_id = fields.Integer(string='Record ID')
    mip_id = fields.Many2one('cnt_pm.mip', string='MIP')
    proposal_id = fields.Many2one('cnt_pm.proposal', string='Proposal')
    mipro_id = fields.Many2one('cnt_pm.mipro',string='Mipro')
    mil_id = fields.Many2one('cnt_pm.mil', string='Mil')
    spp_id = fields.Many2one('cnt_pm.spp', string='SPP')