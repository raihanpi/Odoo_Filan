from odoo import api, models, fields # Mandatory

class Provinsi(models.Model):
    _name = 'cnt_pm.provinsi' # name_of_module.name_of_class 
    _description = 'model provinsi' # Some note of table
    _rec_name = 'prov'

    prov = fields.Char(string="Nama Provinsi", required=False)
    kdprov = fields.Char(string="Kode Provinsi", size=16, required=False) 

class Kota(models.Model):
    _name = 'cnt_pm.kota' # name_of_module.name_of_class 
    _description = 'model kota' # Some note of table
    _rec_name = 'kota'

    kota = fields.Char(string="Nama kota", required=False)
    kdkota = fields.Char(string="Kode kota", size=16, required=False)
    province = fields.Many2one(comodel_name='cnt_pm.provinsi', string='Nama Provinsi', required=False)
    
    kdprov = fields.Char(compute="_compute_kdprov", string="Kode provinsi", size=16, required=False, store=True)

    @api.depends('province')
    def _compute_kdprov(self):
        for record in self:
            record.kdprov = record.province.kdprov


class Kecamatan(models.Model):
    _name = 'cnt_pm.kecamatan' # name_of_module.name_of_class 
    _description = 'model kecamatan' # Some note of table
    _rec_name = 'kec'

    kec = fields.Char(string="Nama kecamatan", required=False) 
    kdkec = fields.Char(string="Kode kecamatan", size=16, required=False) 
    city = fields.Many2one(
        comodel_name='cnt_pm.kota', string='Kota', required=False)
    provinsi_id = fields.Many2one(
        comodel_name='cnt_pm.provinsi', string='Provinsi', required=False)
    
    kdprov = fields.Char(compute="_compute_kdprov", string="Kode provinsi", size=16, required=False, store=True)
    kdkota = fields.Char(compute="_compute_kdkota", string="Kode kota", size=16, required=False, store=True)

    @api.depends('provinsi_id')
    def _compute_kdprov(self):
        for record in self:
            record.kdprov = record.provinsi_id.kdprov

    @api.depends('city')
    def _compute_kdkota(self):
        for record in self:
            record.kdkota = record.city.kdkota
class Desa(models.Model):
    _name = 'cnt_pm.desa' # name_of_module.name_of_class 
    _description = 'model kelurahan' # Some note of table
    _rec_name = 'kel'

    kel = fields.Char(string="Nama Desa", required=False) 
    kdkel = fields.Char(string="Nomor Induk Desa", size=16, required=False) 
    district = fields.Many2one(comodel_name='cnt_pm.kecamatan', string='Nama Kecamatan', required=False)
    kota = fields.Many2one(comodel_name='cnt_pm.kota', string='Nama Kota', required=False)
    provinsi = fields.Many2one(comodel_name='cnt_pm.provinsi', string='Nama Provinsi', required=False)
    kdprov = fields.Char(string="Kode Provinsi", size=16, required=False) 

    kdprov = fields.Char(compute="_compute_kdprov", string="Kode provinsi", size=16, required=False, store=True)
    kdkota = fields.Char(compute="_compute_kdkota", string="Kode kota", size=16, required=False, store=True) 
    kdkec = fields.Char(compute="_compute_kdkec", string="Kode kecamatan", size=16, required=False, store=True)

    @api.depends('provinsi')
    def _compute_kdprov(self):
        for record in self:
            record.kdprov = record.provinsi.kdprov

    @api.depends('kota')
    def _compute_kdkota(self):
        for record in self:
            record.kdkota = record.kota.kdkota

    @api.depends('district')
    def _compute_kdkec(self):
        for record in self:
            record.kdkec = record.district.kdkec


