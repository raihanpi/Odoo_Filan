from odoo import api, fields, models
from odoo.exceptions import ValidationError
import requests
import urllib
import datetime

class Mipro(models.Model):
    _name = 'cnt_pm.mipro'
    _description = 'cnt_pm Mipro'
    _rec_name = 'proposal_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    program_name = fields.Char(string='Nama Program')
    nomor_mipro = fields.Char(string='Nomor Mipro')
    rm_id = fields.Many2one(comodel_name='res.users', string='Nama Pengaju', required=True, tracking=True)
    partner_id = fields.Many2one(comodel_name='res.partner', string='Nama Mitra', required=True, tracking=True)
    start_implementation = fields.Date(string='Tanggal Dimulai Implementasi', tracking=True)
    end_implementation = fields.Date(string='Tanggal Berakhir Implementasi', tracking=True)
    mipro_spp_ids = fields.One2many(comodel_name='cnt_pm.spp', inverse_name='mipro_id', string='SPP')
    number_pks = fields.Char(string='Nomor PKS')
    pks_number = fields.Char(string='Nomor PKS')
    mil_id = fields.Many2one(comodel_name='cnt_pm.mil', string='Nomor MIL')
    donation_status = fields.Selection([
        ('lunas', 'Lunas'),
        ('talangan', 'Talangan')
    ], string='Status Dana', tracking=True)
    rab_all = fields.Char(string='Rab All')
    custom_number = fields.Char(string='Custom Number', readonly=True)

    proposal_id = fields.Many2one(comodel_name='cnt_pm.proposal', string='Nama Program')
    state = fields.Selection([
        ('1_open', 'Open'),
        ('2_staffreplied', 'Review'), 
        # ('needreview', 'Review 2'),
        ('4_closed', 'Closed'),
        ('5_pending', 'Pending')
    ], default="1_open", string='Status', tracking=True)

    note = fields.Html(string='Catatan')

    # Informasi Penyaluran
    log_message_ids = fields.One2many('cnt_pm.log', 'mipro_id', string='Log Messages')
    nomor_proposal = fields.Char('Nomor Proposal') 
    program_target = fields.Char('Sasaran Program', tracking=True)
    nomor_mou = fields.Char(string='Nomor MOU')
    donation_prediction = fields.Float(size=15, digits=(15, 0), default=0, string='Nominal Donasi', tracking=True)
    status_proposal = fields.Selection([
        ('1_open', 'Open'),
        ('2_staffreplied', 'Process'),
        ('3_needreview', 'Need Review'),
        ('4_closed', 'Closed'),
        ('pending', 'Pending')
    ], default="1_open", string='Status Proposal', tracking=True, related='proposal_id.status_proposal')
    pelaksana = fields.Many2one(comodel_name='res.partner', string='Pelaksana Program', tracking=True)

    # Lokasi Penyaluran
    provinsi_id = fields.Many2one('cnt_pm.provinsi', string='Provinsi', tracking=True)
    kota_id = fields.Many2one('cnt_pm.kota', string='Kabupaten/Kota', tracking=True)
    kelurahan_id = fields.Many2one('cnt_pm.kecamatan', string='Kecamatan/Kelurahan', tracking=True)
    desa_id = fields.Many2one('cnt_pm.desa', string='Desa', tracking=True)
    alamat_penyaluran = fields.Html(string='Alamat Penyaluran', placeholder='Detail Alamat Penyaluran', tracking=True)
    
    # KPI
    kpi_project = fields.Html(string='KPI Project', tracking=True)
    ket_lainnya = fields.Html(string='Keterangan Lainnya', tracking=True)
    deskripsi_penyaluran = fields.Text('Deskripsi Penyaluran', tracking=True)

    # Dokumen
    bentuk_dokumen_ids= fields.One2many(comodel_name='cnt_pm.bentuk_laporan', inverse_name='mipro_id', tracking=True)

    # Timeline
    timeline_ids = fields.One2many(comodel_name='cnt_pm.timeline', inverse_name='mipro_id', tracking=True)

    # Publikasi
    publikasi_ids = fields.One2many(comodel_name='cnt_pm.publikasi', inverse_name='mipro_id', tracking=True)


    spp_ids = fields.One2many(comodel_name='cnt_pm.spp', inverse_name='mipro_id', tracking=True)
    total = fields.Float(size=15, digits=(15, 0), default=0, string='Total', compute='_calculate_subtotal',  store=True, tracking=True)

    # Assignee
    pi_leader_id = fields.Many2one('res.partner', string='PM Leader')
    pi_project_ids = fields.Many2many(comodel_name='res.partner', string='PM Project')
    

    # ini buat total di pengajuan anggaran
    @api.depends('donasi_ids')
    def _calculate_subtotal(self):
        total = sum(record.nominal_donasi for record in self.donasi_ids)
        self.total = total

    description_mipro = fields.Text(string='Description')

    donasi_ids = fields.One2many(comodel_name='cnt_pm.donasi', inverse_name='mipro_id')

    def kanban_color(self, state):
        # Define the color mapping based on the status field
        color_mapping = {
            '1_open': 'kanban-color-grey',
            '2_staffreplied': 'kanban-color-yellow',
            '4_closed': 'kanban-color-green'
        }
        return color_mapping.get(state, '')
    
    # Api untuk informasi penyaluran
    @api.onchange('proposal_id')
    def set_nomor_proposal(self):
        self.nomor_proposal = self.proposal_id.nomor_proposal
        # self.pelaksana = self.proposal_id.rm_name_id
        self.donation_prediction = self.proposal_id.donation_prediction
        self.rab_all = self.proposal_id.rab_all
        self.deskripsi_penyaluran = self.proposal_id.deskripsi_penyaluran
        self.status_proposal = self.proposal_id.status_proposal

    @api.model
    def create(self, vals):
        if not vals.get('nomor_mipro'):
            # Generate the nomor_mipro
            last_mipro = self.search([], order="id desc", limit=1)
            nomor_mipro = 'MIPRO.P1' if not last_mipro else last_mipro.nomor_mipro
            vals['nomor_mipro'] = nomor_mipro

        return super(Mipro, self).create(vals)

    #validasi 2 nama program di mipro
    @api.constrains('proposal_id')
    def _check_duplicate_proposal(self):
        for record in self:
            # Menghitung jumlah record dengan proposal_id yang sama
            count = self.search_count([('proposal_id', '=', record.proposal_id.id)])
            
            # Menetapkan aturan validasi (misalnya, tidak boleh lebih dari satu record dengan proposal_id yang sama)
            if count > 1:
                raise ValidationError("Nama program ini sudah memiliki MIPRO!")
            
    # create number mipro
    @api.model
    def create(self, vals):
        # Get current year and month
        current_year = datetime.datetime.now().strftime("%Y")
        current_month = datetime.datetime.now().strftime("%m")
        month_mapping = {
            "01": "I",
            "02": "II",
            "03": "III",
            "04": "IV",
            "05": "V",
            "06": "VI",
            "07": "VII",
            "08": "VIII",
            "09": "IX",
            "10": "X",
            "11": "XI",
            "12": "XII",
        }
        current_month_roman = month_mapping[current_month]
        prefix = 'PKS'
        suffix = 'FILANTRA'
        current_year_pks = fields.Date.today().year

        # if not vals.get('number_pks'):
        #     records = self.search([
        #         ('number_pks', 'like', f'%/{prefix}/{suffix}/{current_month_roman}/{current_year_pks}')
        #     ], order='number_pks desc', limit=1)
        #     if records:
        #         latest_number = records.number_pks
        #         latest_count = int(latest_number.split('/')[0])  # Extract the count
        #         new_count = latest_count + 1  # Increment the count
        #     else:
        #         new_count = 1  # If no records exist, start from 1

        #     custom_number = f'{new_count:02}/{prefix}/{suffix}/{current_month_roman}/{current_year_pks}'
        #     vals['number_pks'] = custom_number

        if not vals.get('nomor_mipro'):
            nomor_mipro = 'MIPRO'
            code_count = self.env['cnt_pm.mipro'].search_count([('nomor_mipro', 'like', nomor_mipro + '%')])
            if code_count > 0:
                last_mip = self.env['cnt_pm.mipro'].search([('nomor_mipro', 'like', nomor_mipro + '%')], order="id desc", limit=1)
                last_mip_number = int(last_mip.nomor_mipro.split('.P')[-1].split('.')[0])
                nomor_mipro += '.P' + str(last_mip_number + 1) + '.' + str(current_month_roman) + '.' + str(current_year)
            else:
                nomor_mipro += '.P1.' + str(current_month_roman) + '.' + str(current_year)
            vals['nomor_mipro'] = nomor_mipro
        
        
        mipro = super(Mipro, self).create(vals)
        # Notif create proposal
        notif  = self.env['cnt_pm.mipro'].search([('id', '=', mipro.id)])
        current_user = self.env['res.users'].browse(self._uid)
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mipro_create_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(notif.partner_id.name))
            message = message.replace('<name_program>', str(notif.proposal_id.cover_title))
            message = message.replace('<rm_name_id>', str(notif.rm_id.name))
            message = message.replace('<name_pelaksana_program>', str(notif.pelaksana.name))
            message = message.replace('<created_by>', str(current_user.name))
            message = message.replace('<id_mipro>', str(mipro.id))
            message = message.replace('<pm_leader_id>', str(mipro.pi_leader_id.name))
            pi_project_names = ""
            for project_id in mipro.pi_project_ids:
                pi_project_names += str(project_id.name) + ", "
            message = message.replace('<pi_project_ids>', pi_project_names)
            self.send(message, urls)
    
        return mipro

    # API Telegram
    def send (self, message, urls):
        urllib.parse.quote(message)
        url = "https://api.telegram.org/bot" + str(urls.api_key) + "/sendMessage?text=" + \
                message+"&chat_id="
        if urls.chat_id != False:
            try:
                requests.get(url + urls.chat_id)
            except requests.exceptions.ReadTimeout:
                print("TIMEOUT")
            pass

    def action_reply(self):
        self.ensure_one()
        return {
            'name': 'Reply Message',
            'type': 'ir.actions.act_window',
            'res_model': 'cnt_pm.reply',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
            'context': {
                'default_model': 'cnt_pm.mipro',
                'default_res_id': self.id,
                'default_field': 'description_mipro',
            },
        }

    # Notif Pedding
    def pending_buttons(self):
        self.state = '5_pending'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mipro_pending_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<name_program>', str(self.proposal_id.cover_title))
            message = message.replace('<rm_name_id>', str(self.rm_id.name))
            message = message.replace('<name_pelaksana_program>', str(self.pelaksana.name))
            message = message.replace('<id_mipro>', str(self.id))
            message = message.replace('<pm_leader_id>', str(self.pi_leader_id.name))
            pi_project_names = ""
            for project_id in self.pi_project_ids:
                pi_project_names += str(project_id.name) + ", "
            message = message.replace('<pi_project_ids>', pi_project_names)
            self.send(message, urls)

    # Notif close
    def close_buttons(self):
        self.state = '2_staffreplied'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mipro_review_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<name_program>', str(self.proposal_id.cover_title))
            message = message.replace('<rm_name_id>', str(self.rm_id.name))
            message = message.replace('<name_pelaksana_program>', str(self.pelaksana.name))
            message = message.replace('<id_mipro>', str(self.id))
            message = message.replace('<pm_leader_id>', str(self.pi_leader_id.name))
            pi_project_names = ""
            for project_id in self.pi_project_ids:
                pi_project_names += str(project_id.name) + ", "
            message = message.replace('<pi_project_ids>', pi_project_names)
            self.send(message, urls)

    # Notif approve
    def approve_buttons(self):
        self.state = '4_closed'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mipro_closed_notif')])
        current_user = self.env['res.users'].browse(self._uid)
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<name_program>', str(self.proposal_id.cover_title))
            message = message.replace('<rm_name_id>', str(self.rm_id.name))
            message = message.replace('<name_pelaksana_program>', str(self.pelaksana.name))
            message = message.replace('<current_user>', str(current_user.name))
            message = message.replace('<id_mipro>', str(self.id))
            message = message.replace('<pm_leader_id>', str(self.pi_leader_id.name))
            pi_project_names = ""
            for project_id in self.pi_project_ids:
                pi_project_names += str(project_id.name) + ", "
            message = message.replace('<pi_project_ids>', pi_project_names)
            self.send(message, urls)

    # def write(self, vals):
    #     if 'status_mil' in vals:
    #         if vals['state'] == '4_closed':
    #             target_model = self.env['project.project']
    #             for mil in self:
    #                 partner = mil.partner_id
    #                 print('INI ID PARTNERNYA', partner)
    #                 if mil.partner_id:
    #                     order_product = target_model_product.create({
    #                         'name': mil.proposal_id.cover_title,
    #                         'list_price': mil.mil_agreement_donation,
    #                         'sale_ok':True,
    #                         'purchase_ok':False
    #                     })
    #                 if mil.partner_id:
    #                     order = target_model.create({
    #                         'partner_id': mil.partner_id.id,
    #                     })
    #                     order.write({'order_line': [(0, 0, {
    #                         'product_id': order_product.id,
    #                         'tax_id':False
    #                     })]})
                                
    #                     # Hapus entri 'tax_id' yang ada pada entri Order Line
    #                     order.order_line.mapped('tax_id').unlink()
    # return res

    @api.onchange('proposal_id')
    def onchange_proposal_id(self):
        if self.proposal_id:
            # Assuming that program_id is a many2one field related to your program model
            mil_record = self.env['cnt_pm.mil'].search([
                ('proposal_id', '=', self.proposal_id.id),
            ], limit=1)

            if mil_record and not self.pks_number :
                self.pks_number = mil_record.pks_number