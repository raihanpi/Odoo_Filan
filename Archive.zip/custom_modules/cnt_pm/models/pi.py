from odoo import api, fields, models
from odoo.exceptions import ValidationError

class Pi(models.Model):
    _name = 'cnt_pm.pi'
    _description = 'cnt_pm Pi'
    _rec_name = 'pembagian_pi_year'

    # pembagian_pi_partner_ids = fields.Many2one('comodel_name', string='partner_id')
    # pembagian_pi_program = fields.Many2one('comodel_name', string='field_name')
    pembagian_pi_score = fields.Integer(string='Skor')
    pembagian_pi_kpi_selection = fields.Selection([
        ('ya', 'ya'),
        ('tidak','tidak'),
    ], string='KPI')

    pembagian_pi_character = fields.Selection([
        ('ya', 'ya'),
        ('tidak','tidak'),
    ], string='Karakter')

    pembagian_pi_executor = fields.Selection([
        ('ya', 'ya'),
        ('tidak','tidak'),
    ], string='Pelaksana')

    pembagian_pi_time = fields.Selection([
        ('ya', 'ya'),
        ('tidak','tidak'),
    ], string='Waktu')

    pembagian_pi_region = fields.Selection([
        ('ya', 'ya'),
        ('tidak','tidak'),
    ], string='Wilayah')

    pembagian_pi_status = fields.Selection([
        ('ya', 'ya'),
        ('tidak','tidak'),
    ], string='Status')

    pembagian_pi_year = fields.Char(string='Tanggal')
    # pembagian_pi_pj = fields.Many2one('comodel_name', string='field_name')
    # pembagian_pi_pi = fields.Many2one('comodel_name', string='field_name')
    pembagian_pi_implementator = fields.Selection([
        ('ya', 'ya'),
        ('tidak','tidak'),
    ], string='Implementator')
    # pembagian_pi_rm = fields.Many2one('comodel_name', string='field_name')
    pembagian_pi_report = fields.Selection([
        ('ya', 'ya'),
        ('tidak','tidak'),
    ], string='Laporan')
    pembagian_pi_donation = fields.Float(string='Donasi')
    pembagian_pi_dss = fields.Float(string='dss')
    pembagian_pi_efficiency = fields.Float(string='Efisiensi')
    pembagian_pi_dp =fields.Float(string='dp')
    pembagian_pi_start_project =fields.Char(string='Awal Project')
    pembagian_pi_project_completion =fields.Char(string='Akhir Project')
    pembagian_pi_kpi = fields.Integer(string='kpi')
    pembagian_pi_information = fields.Char(string='Keterangan')
    pi_ids=fields.Char('PM Ids',copy=False,readonly=False,index=True,default=lambda self:_('New'))
    
    @api.model
    def create(self, vals):
        if not vals.get('pi_ids'):
            pi_ids = 'PM-'

            code_count = self.env['cnt_pm.pi'].search_count([('pi_ids', 'like', pi_ids + '%')])
            if code_count > 0:
                last_pi = self.env['cnt_pm.pi'].search([('pi_ids', 'like', pi_ids + '%')], order="id desc", limit=1)
                last_pi_number = int(last_pi.pi_ids.split('-')[-1])
                pi_ids += str(last_pi_number + 1).zfill(3)
            else:
                pi_ids += '001'
                
            vals['pi_ids'] = pi_ids
        
        pI = super(Pi, self).create(vals)
        
        return pI

    # @api.model
    # def create(self, values):
    #     res = super(Proposal, self).create(values)
    #     try:
    #         notif = {
    #             'cover_title': values['name'],
    #         }
    #     except:
    #         pass
    #         return res

    # score = fields.Integer(string="Score",compute="_compute_count_correct_answer")
    # status = fields.Selection([('a', 'Very Good'), ('b', 'Good'),('c','Try Hard')], string='Status')
    # @api.depends("score")
    # def _status(self):
    #     for r in self:
    #         if r.score > 79:
    #             r.status = 'a'
    #         elif r.score > 59:
    #             r.status = 'b'
    #         else:
    #             r.status = 'c'

    # @api.depends('submission_answer_ids')
    # def _compute_count_correct_answer(self):
    #     for record in self:
    #         jumlah_soal = len(record.quiz_id.question_ids)
    #         if jumlah_soal == 0:
    #             record.score = False
    #             continue
    #         student_answer = 0
    #         print(student_answer)
    #         for answer in record.submission_answer_ids:
    #              student_answer = student_answer + answer.poin + answer.poin_short_answer
    #         print(student_answer)

    #         record.score = student_answer / jumlah_soal * 10.0
