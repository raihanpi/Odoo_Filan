from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
import requests
import urllib
import json
import pathlib
from google.cloud import storage
from google.oauth2 import service_account
import tempfile
import os
import base64
from pydrive.drive import GoogleDrive
from pydrive.auth import GoogleAuth

class Mil(models.Model):
    _name = 'cnt_pm.mil'
    _description = 'cnt_pm Mil'
    _rec_name = 'proposal_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    partner_id = fields.Many2one(comodel_name='res.partner', string='Nama Mitra', tracking=True)
    mil_no_mil = fields.Char(string='No Dokumen')
    mil_name = fields.Char(string='Nama Mitra')
    mil_program_name = fields.Char(string='Nama Program')
    mil_draft = fields.Char(string='File', placeholder='Tempelkan url disini', tracking=True)
    mil_draft_upload = fields.Binary(string='File Test', tracking=True)
    url = fields.Char(string='URL', tracking=True)
    filename = fields.Char(string='Filename', tracking=True)
    folder = fields.Char(string='Folder', tracking=True, default=lambda self: self.env.user.name)
    mil_spj_number = fields.Char(string='Nomor PKS')
    pks_number = fields.Char(string='Nomor PKS')
    mil_donation = fields.Float(size=15, digits=(15, 0), default=0, string='Perkiraan Donasi', tracking=True)
    mil_agreement_donation = fields.Float(size=15, digits=(15, 0), default=0, string='Kesepakatan Donasi', tracking=True)
    custom_number = fields.Char(string='Custom Number', readonly=True)
    mou_date = fields.Date('Tanggal MOU', tracking=True)
    description_mil = fields.Text(string='Description')
    log_message_ids = fields.One2many('cnt_pm.log', 'mil_id', string='Log Messages')
    status_mil = fields.Selection([
        ('1_open', 'Open'),
        ('2_staffreplied', 'Process'),
        ('3_needreview', 'Need Review'),
        ('4_closed', 'Closed'),
        ('5_pending', 'Pending')
    ], default="1_open", string='Status', tracking=True)
    deadline = fields.Datetime(string="Due Date")
    
    #from
    mil_from = fields.Char(string='From')
    mil_branch = fields.Char(string='Cabang/bagian')
    mil_note = fields.Char(string='Keterangan', tracking=True)
    mil_application_date = fields.Char(string='Tanggal Pengajuan')
    proposal_id = fields.Many2one(comodel_name='cnt_pm.proposal', string='Nama Program', tracking=True)
    donation_status = fields.Selection([
        ('lunas', 'Lunas'),
        ('talangan', 'Talangan')
    ], string='Status Dana', tracking=True)

    #jenis perjanjian
    mil_agreement_type = fields.Char(string='Nama Program kerjasama')
    mil_partner_name = fields.Char(comodel_name="res.partner",string='Nama Mitra')
    mil_partnership_logo = fields.Html(string='Logo mitra kerjasama')
    mil_logo_partnership = fields.Binary(string='Logo Mitra')
    mil_location_program_collab = fields.Char(string='lokasi program')
    mil_location_spj = fields.Char(string='Tanggal SPJ di butuhkan')
    mil_nomor_proposal = fields.Char('Nomor Proposal') 

    #isi perjanjian
    mil_location_signature = fields.Char(string='Tempat & tanggal tanda tangan')
    mil_term_agreement = fields.Char(string='Jangka Waktu perjanjian')
    mil_general_content_agreement = fields.Char(string='Isi Perjanjian (secara umum)')
    mil_right_boligation_partner = fields.Char(string='Hak dan kewajiban pihak mitra')
    mil_right_obligation_rz = fields.Char(string='Hak dan kewajiban pihak RZ')
    mil_agrement_price = fields.Char(string='Nominal perjanjian')
    mil_tax_information = fields.Char(string='Informasi pajak')
    # mil_transfer_method = fields.Char('Cara Pembayaran')
    mil_transfer_method = fields.Selection([
        ('transfer', 'cash')
    ], string='Cara Pembayaran')
    mil_payment_period = fields.Char(string='Waktu pembayaran')
    mil_payment_account = fields.Char(string='Rekening tujuan pembayaran')

    #data komparisi
    ##wakil donatur perorangan
    mil_contributor_name = fields.Char(string='Nama')
    mil_contributor_role = fields.Char(string='Jabatan')
    mil_contributor_address = fields.Char(string='Alamat Lengkap')
    mil_poa_number = fields.Char(string='No Surat Kuasa (apabila ada)')
    mil_no_identity = fields.Char(string='No Identitas')
    ##wakil donatur lembaga / corporate
    mil_complete_institution_name = fields.Char(string='Nama Lembaga')
    mil_complete_institution_address = fields.Char(string='Alamat Lengkap Lembaga')
    mil_legal_entry_data = fields.Char(string='Data Badan Hukum')
    mil_founding_deed_number = fields.Char(string='No Akta Pendirian')
    mil_deed_date = fields.Char(string='Tanggal Akta')
    mil_notary_name = fields.Char(string='Nama Notaris')
    mil_statue_gazettedata = fields.Char(string='Data Berita Negara')
    mil_full_name_signatory = fields.Char(string='Nama lengkap penandatangan')
    mil_signatory_position = fields.Char(string='Jabatan penandatangan')
    mil_signatory_document_number = fields.Char(string='No dokumen jabatan')
    mil_signatory_document_date = fields.Char(string='Tgl dokumen jabatan penandatangan')

    #info korespondensi
    ##pihak cnt_pm
    mil_pic_pf_name = fields.Char(string='Nama PIC')
    mil_pic_pf_address = fields.Char(string='Alamat PIC')
    mil_pic_pf_phone_office_number = fields.Char(string='No Tlp kantor PIC')
    mil_pic_pf_phone_number = fields.Char(string='No HP PIC')
    mil_pic_pf_email = fields.Char(string='Alamat email PIC')

    ##pihak mitra
    mil_pic_name = fields.Char(string='Nama PIC')
    mil_pic_address = fields.Char(string='Alamat PIC')
    mil_pic_phone_office_number = fields.Char(string='No Tlp kantor PIC')
    mil_pic_phone_number = fields.Char(string='No HP PIC')
    mil_pic_email = fields.Char(string='Alamat email PIC')

    #lampiran lampiran
    mil_proposal_number = fields.Char(string='No Proposal')
    mil_draft_pks = fields.Char(string='Draf PKS')
    mil_note = fields.Char(string='Keterangan')

    #CEO
    mil_ceo = fields.Char(string='CEO')
    mil_funding_director = fields.Char(string='Direktur Funding')
    mil_operational_director = fields.Char(string='Direktur Operasional')
    mil_program_director = fields.Char(string='Direktur Program')
    mil_program_comitee = fields.Char(string='Komite program')
    mil_approval_giver_from_comitee = fields.Char(string='Nama pemberi approval dari komite')
    rm_div_head = fields.Html(string='field_name')

    state = fields.Selection([
        ('draft', 'Draft'),
        ('2_staffreplied', 'Staff Replied'),
        ('approve', 'Approve'),
        ('cancel', 'Cancel')
    ], default='draft', string="State", tracking=True)

    # Action
    def action_staffreplied(self):
        self.state = "stafreplied"

    def action_approve(self):
        if self.mil_agreement_donation == 0:
            raise ValidationError("Kesepakatan donasi harus diisi!!!")
        else:
            self.state = "approve"

    def action_cancel(self):
        self.state = "cancel"

    def kanban_color(self, status_mil):
        # Define the color mapping based on the status field
        color_mapping = {
            '1_open':'kanban-color-red',
            '3_needreview':'kanban-color-blue',
            '2_staffreplied':'kanban-color-yellow',
            '4_closed':'kanban-color-green',
            '5_pending':'kanban-color-orange'
        }
        return color_mapping.get(status_mil, '')

    # relasi status dana dan donasi dari mil ke mipro 
    @api.onchange('donation_status')
    def onchange_status_dana(self):
        # Update the 'status_dana' field in the 'mil' model
        mil_model = self.env['cnt_pm.mipro']
        mil_records = mil_model.search([])
        mil_records.write({'donation_status': self.donation_status})

    @api.onchange('mil_agreement_donation')
    def onchange_donation_prediction(self):
        # Update the 'status_dana' field in the 'mil' model
        mil_model = self.env['cnt_pm.mipro']
        mil_records = mil_model.search([])
        mil_records.write({'donation_prediction': self.mil_agreement_donation})
    
    @api.onchange('proposal_id')
    def _onchange_proposal(self):
        self.partner_id = self.proposal_id.partner_id
        self.mil_program_name = self.proposal_id.cover_title
        self.mil_donation = self.proposal_id.donation_prediction

    @api.constrains('proposal_id')
    def getProposal(self):
        self.mil_partner_name = self.proposal_id.partner_id
        self.mil_location_program_collab = self.proposal_id.plan_lokasi
        self.mil_nomor_proposal = self.proposal_id.nomor_proposal

    #Create no Dokumen
    # @api.model
    # def create(self, vals):
    #     # Get current year and month
    #     current_year = datetime.datetime.now().strftime("%Y")
    #     current_month = datetime.datetime.now().strftime("%m")
    #     month_mapping = {
    #         "01": "I",
    #         "02": "II",
    #         "03": "III",
    #         "04": "IV",
    #         "05": "V",
    #         "06": "VI",
    #         "07": "VII",
    #         "08": "VIII",
    #         "09": "IX",
    #         "10": "X",
    #         "11": "XI",
    #         "12": "XII",
    #     }
    #     current_month_roman = month_mapping[current_month]
    #     prefix = 'PKS'
    #     suffix = 'FILANTRA'
    #     current_year_pks = fields.Date.today().year

    #     # if not vals.get('mil_spj_number'):
    #     #     records = self.search([
    #     #         ('mil_spj_number', 'like', f'%/{prefix}/{suffix}/{current_month_roman}/{current_year_pks}')
    #     #     ], order='mil_spj_number desc', limit=1)
    #     #     if records:
    #     #         latest_number = records.mil_spj_number
    #     #         latest_count = int(latest_number.split('/')[0])  # Extract the count
    #     #         new_count = latest_count + 1  # Increment the count
    #     #     else:
    #     #         new_count = 1  # If no records exist, start from 1

    #     #     custom_number = f'{new_count:02}/{prefix}/{suffix}/{current_month_roman}/{current_year_pks}'
    #     #     vals['mil_spj_number'] = custom_number

    #     if not vals.get('mil_no_mil'):
    #         mil_no_mil = 'MIL'
    #         code_count = self.env['cnt_pm.mil'].search_count([('mil_no_mil', 'like', mil_no_mil + '%')])
    #         if code_count > 0:
    #             last_mip = self.env['cnt_pm.mil'].search([('mil_no_mil', 'like', mil_no_mil + '%')], order="id desc", limit=1)
    #             last_mip_number = int(last_mip.mil_no_mil.split('.P')[-1].split('.')[0])
    #             mil_no_mil += '.P' + str(last_mip_number + 1) + '.' + str(current_month_roman) + '.' + str(current_year)
    #         else:
    #             mil_no_mil += '.P1.' + str(current_month_roman) + '.' + str(current_year)
    #         vals['mil_no_mil'] = mil_no_mil
    
    #     mil = super(Mil, self).create(vals)

    #     # Notifikasi Create MIL
    #     notif  = self.env['cnt_pm.mil'].search([('id', '=', mil.id)])
    #     current_user = self.env['res.users'].browse(self._uid)
    #     urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
    #     template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mil_create_notif')])
    #     if urls.notif_via == 'telegram':
    #         message = template_telegram.template_content
    #         message = message.replace('<partner_id>', str(notif.partner_id.name))
    #         message = message.replace('<name_program>', str(notif.proposal_id.cover_title))
    #         message = message.replace('<file>', str(notif.mil_draft))
    #         message = message.replace('<created_by>', str(current_user.name))
    #         message = message.replace('<id_mil>', str(mil.id))
    #         self.send(message, urls)
    
    #     return mil


    def send (self, message, urls):
        urllib.parse.quote(message)
        url = "https://api.telegram.org/bot" + str(urls.api_key) + "/sendMessage?text=" + \
                message+"&chat_id="
        if urls.chat_id != False:
            try:
                requests.get(url + urls.chat_id)
            except requests.exceptions.ReadTimeout:
                print("TIMEOUT")
            pass

    def action_reply(self):
        self.ensure_one()
        return {
            'name': 'Reply Message',
            'type': 'ir.actions.act_window',
            'res_model': 'cnt_pm.reply',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
            'context': {
                'default_model': 'cnt_pm.mil',
                'default_res_id': self.id,
                'default_field': 'description_mil',
            },
        }
        
    # Notifikasi button pending
    def pending_buttons(self):
        self.status_mil = '5_pending'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mil_pending_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(self.partner_id.name))
            message = message.replace('<name_program>', str(self.proposal_id.cover_title))
            message = message.replace('<id_mil>', str(self.id))
            # message = message.replace('<name>', str(self.name)) # sesuaikan dengan konten message
            self.send(message, urls)
    
    # Notifikasi button close
    def close_buttons(self):
        self.status_mil = '3_needreview'
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mil_review_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            # message = message.replace('<name>', str(self.name)) # sesuaikan dengan konten message
            message = message.replace('<partner_id>', str(self.partner_id.name))            
            message = message.replace('<name_program>', str(self.proposal_id.cover_title))
            message = message.replace('<file>', str(self.mil_draft))
            message = message.replace('<id_mil>', str(self.id))
            self.send(message, urls)

    # Notifikasi button approve
    def approve_buttons(self):
        if self.mil_agreement_donation == 0.0:
            raise ValidationError("Kesepakatan donasi harus diisi!")
        else:
            self.status_mil = "4_closed"
            urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
            template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mil_closed_notif')])
            current_user = self.env['res.users'].browse(self._uid)
            if urls.notif_via == 'telegram':
                message = template_telegram.template_content
                # message = message.replace('<name>', str(self.name)) # sesuaikan dengan konten message
                message = message.replace('<partner_id>', str(self.partner_id.name))
                message = message.replace('<name_program>', str(self.proposal_id.cover_title))
                message = message.replace('<current_user>', str(current_user.name))
                message = message.replace('<file>', str(self.mil_draft))
                message = message.replace('<id_mil>', str(self.id))
                self.send(message, urls)

    # autocreate ke modul sale dan produk kalao spp close
    def write(self, vals):
        if 'mil_draft_upload' in vals:
            gauth, drive = self.login()
            user = self.env['res.users'].search(
                [('id', '=', self.env.user.id)])
            parent_name = "FIS"
            folder_name = "MIL"
            parent_id = self.getFolderID(drive, parent_name)
            folder_id = self.getFolderID(drive, folder_name, parent_id=parent_id)
            partner_name = self.env['res.partner'].search([('id', '=', self.partner_id.id)])
            proposal_name = self.env['cnt_pm.proposal'].search([('id', '=', self.proposal_id.id)])

                
            now = datetime.datetime.now()
            filename = "MIL_" + str(partner_name.name)+ "_" + str(proposal_name.cover_title) + "_" + str(now.strftime('%d')) + "_"  + str(now.strftime('%B')) + "_" + str(now.strftime('%Y'))

            vals['url'] = self.uploadImageFromString(
                gauth, folder_id, filename, vals['mil_draft_upload'])
            vals['mil_draft_upload'] = False
            vals['filename'] = filename

        if self.status_mil == '4_closed' :
            raise ValidationError('Sudah diclose, tidak dapat diclose kembali!!!')
        # if vals['status_mil'] == '4_closed' and self.mil_agreement_donation == 0:
        #     raise ValidationError('Kesepakatan donasi tidak boleh nol!!!')
        res = super(Mil, self).write(vals)
        # if 'status_mil' in vals:
        #     if vals['status_mil'] == '4_closed':
        #         target_model = self.env['sale.order']
        #         target_model_product = self.env['product.template']
        #         target_model_order_line = self.env['sale.order.line']
        #         for mil in self:
        #             partner = mil.partner_id
        #             print('INI ID PARTNERNYA', partner)
        #             if mil.partner_id:
        #                 order_product = target_model_product.create({
        #                     'name': mil.proposal_id.cover_title,
        #                     'list_price': mil.mil_agreement_donation,
        #                     'sale_ok':True,
        #                     'purchase_ok':False
        #                 })
        #             if mil.partner_id:
        #                 order = target_model.create({
        #                     'partner_id': mil.partner_id.id,
        #                 })
        #                 order.write({'order_line': [(0, 0, {
        #                     'product_id': order_product.id,
        #                     'tax_id':False
        #                 })]})
                        
        #                 # Hapus entri 'tax_id' yang ada pada entri Order Line
        #                 order.order_line.mapped('tax_id').unlink()
        # return res

    #validasi 2 nama program di mil
    @api.constrains('proposal_id')
    def _check_duplicate_proposal(self):
        for record in self:
            if self.search_count([
                ('proposal_id', '=', record.proposal_id.id),
                ('id', '!=', record.id),  # Exclude the current record
            ]) > 0:
                error_message = (
                    f"MIL dengan Program ('{record.proposal_id.cover_title}') "
                    f"Sudah ada pada mitra ('{record.partner_id.name}')."
                )
                raise ValidationError(error_message)

    def login(self):
        # Below code does the authentication
        # part of the code
        gauth = GoogleAuth()

        # Try to load saved client credentials
        gauth.LoadCredentialsFile("mycreds.txt")
        print(gauth.credentials)
        if gauth.credentials is None:
            # Authenticate if they're not there
            print("MASUK KESINI")
            gauth.LocalWebserverAuth()
        elif gauth.access_token_expired:
            # Refresh them if expired
            print("MASUK KE REFRESH")
            gauth.Refresh()
        else:
            # Initialize the saved creds
            gauth.Authorize()
        gauth.SaveCredentialsFile("mycreds.txt")
        drive = GoogleDrive(gauth)

        return gauth, drive

    def createFolder(self, drive, folderName, parent_id=None):
        metadata = {
            'title': folderName,
            "mimeType": "application/vnd.google-apps.folder"
        }

        if parent_id:
            metadata['parents'] = [{'id': parent_id}]

        result = drive.CreateFile(metadata)
        result.Upload(param={'supportsTeamDrives': True})

        new_permission = {
            'id': 'anyoneWithLink',
            'type': 'anyone',
            'value': 'anyoneWithLink',
            'withLink': True,
            'role': 'reader'
        }

        result.auth.service.permissions().insert(
            fileId=result['id'], body=new_permission, supportsTeamDrives=True).execute(http=result.http)

        return result['id']

    def getFolderID(self, drive, folderName, parent_id=None):
        if parent_id:
            folders = drive.ListFile(
                {'q': "title='" + folderName + "' and '"+parent_id+"' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false"}).GetList()
        else:
            folders = drive.ListFile(
                {'q': "title='" + folderName + "' and mimeType='application/vnd.google-apps.folder' and trashed=false"}).GetList()
        for folder in folders:
            if folder['title'] == folderName:
                return folder['id']

        # If not exist create it
        return self.createFolder(drive, folderName, parent_id)

    def uploadImageFromString(self, gauth, folder_id, filename, string):
        metadata = {
            "name": filename,
            "parents": [folder_id]
        }

        files = {
            'data': ('metadata', json.dumps(metadata), 'application/json'),
            'file': base64.b64decode(
                string)
        }
        r = requests.post(
            "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
            headers={"Authorization": "Bearer " +
                     gauth.credentials.access_token},
            files=files
        )
        result = r.json()
        return "https://drive.google.com/uc?id=" + result['id']

    @api.model
    def create(self, values):
        if 'mil_draft_upload' in values:
            gauth, drive = self.login()
            user = self.env['res.users'].search(
                [('id', '=', self.env.user.id)])
            parent_name = "FIS"
            folder_name = "MIL"
            parent_id = self.getFolderID(drive, parent_name)
            folder_id = self.getFolderID(drive, folder_name, parent_id=parent_id)
            partner_name = self.env['res.partner'].search([('id', '=', values['partner_id'])])
            proposal_name = self.env['cnt_pm.proposal'].search([('id', '=', values['proposal_id'])])

                
            now = datetime.datetime.now()
            filename = "MIL_" + str(partner_name.name)+ "_" + str(proposal_name.cover_title) + "_" + str(now.strftime('%d')) + "_"  + str(now.strftime('%B')) + "_" + str(now.strftime('%Y'))

            values['url'] = self.uploadImageFromString(
                gauth, folder_id, filename, values['mil_draft_upload'])
            values['mil_draft_upload'] = False
            values['filename'] = filename

        # Get current year and month
        current_year = datetime.datetime.now().strftime("%Y")
        current_month = datetime.datetime.now().strftime("%m")
        month_mapping = {
            "01": "I",
            "02": "II",
            "03": "III",
            "04": "IV",
            "05": "V",
            "06": "VI",
            "07": "VII",
            "08": "VIII",
            "09": "IX",
            "10": "X",
            "11": "XI",
            "12": "XII",
        }
        current_month_roman = month_mapping[current_month]
        prefix = 'PKS'
        suffix = 'FILANTRA'
        current_year_pks = fields.Date.today().year

        if not values.get('mil_no_mil'):
            mil_no_mil = 'MIL'
            code_count = self.env['cnt_pm.mil'].search_count([('mil_no_mil', 'like', mil_no_mil + '%')])
            if code_count > 0:
                last_mip = self.env['cnt_pm.mil'].search([('mil_no_mil', 'like', mil_no_mil + '%')], order="id desc", limit=1)
                last_mip_number = int(last_mip.mil_no_mil.split('.P')[-1].split('.')[0])
                mil_no_mil += '.P' + str(last_mip_number + 1) + '.' + str(current_month_roman) + '.' + str(current_year)
            else:
                mil_no_mil += '.P1.' + str(current_month_roman) + '.' + str(current_year)
            values['mil_no_mil'] = mil_no_mil

        res = super(Mil, self).create(values)

        # Notifikasi Create MIL
        notif  = self.env['cnt_pm.mil'].search([('id', '=', res.id)])
        current_user = self.env['res.users'].browse(self._uid)
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mil_create_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(notif.partner_id.name))
            message = message.replace('<name_program>', str(notif.proposal_id.cover_title))
            message = message.replace('<file>', str(notif.mil_draft))
            message = message.replace('<created_by>', str(current_user.name))
            message = message.replace('<id_mil>', str(res.id))
            self.send(message, urls)

        return res

    