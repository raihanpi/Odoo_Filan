from odoo import api, fields, models
from odoo.exceptions import ValidationError


class Relasi(models.Model):
    _name = 'cnt_pm.relasi'
    _description = 'Relasi antar Job Title'
    _rec_name = 'rm_id'

    rm_id = fields.Many2one(comodel_name='res.users',string='Nama RM')
    pd_id = fields.Many2one(comodel_name='res.users',string='Nama PD')
    
    user_bank = fields.Char(string='Atas Nama')
    bank_name = fields.Char('Nama Bank')
    account_number = fields.Char('Nomor Rekening')

    # @api.constrains('rm_id', 'pd_id')
    # def _unique(self):
    #     relasi = self.env['cnt_pm.relasi'].search_count([('rm_id', '=', self.rm_id),('pd_id','=',self.pd_id)])
    #     if relasi:
    #         raise ValidationError("Data sudah ada!!!")

    
    # @api.constrains('rm_id')
    # def _unique_rm(self):
    #     rm = self.env['cnt_pm.relasi'].search_count([('rm_id', '=', self.rm_id)])
    #     if rm:
    #         raise ValidationError("RM sudah terikat ke PD yang lain!!!")


    # @api.constrains('pd_id')
    # def _unique_pd(self):
    #     pd = self.env['cnt_pm.relasi'].search_count([('pd_id', '=', self.pd_id.id)])
    #     if pd:
    #         raise ValidationError("PD sudah terikat ke RM yang lain!!!")
