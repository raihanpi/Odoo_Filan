from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
import urllib
import requests

class Pengguna(models.Model):
    _rec_name = 'name'
    _inherit = 'res.partner'

    @api.model
    def create(self, values):
        res = super(Pengguna, self).create(values)
        try:
            data = {
                'name': values['name'],
                'login': values['email'],
                'password': '12345',
            }

            if self.function:
                user = self.env['res.users'].search([('id', '=', self.id)])
                if self.function == 'RM' or self.function == 'rm' or self.function == 'Relational Manager' or self.function == 'relational manager':
                    user.sudo().write({'groups_id': [(4,self.env.ref('cnt_pm.group_rm').id)]})
                elif self.function == 'PD' or self.function == 'pd' or self.function == 'program development' or self.function == 'Program Development':
                    user.sudo().write({'groups_id': [(4, self.env.ref('cnt_pm.group_pd').id)]})

            self.env['res.users'].create(data)
        except:
            pass
        return res


class MIP(models.Model):
    _name = 'cnt_pm.mip'
    _description = 'Memo Internal Project'
    _rec_name = 'nomor_mip'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    description = fields.Text(string='Description')
    log_message_ids = fields.One2many('cnt_pm.log', 'mip_id', string='Log Messages')
    nomor_mip = fields.Char(string='Nomor MIP') 
    name_mip  = fields.Char(string='Nama MIP', tracking=True)
    mitra_id= fields.Many2one (comodel_name= 'cnt_trial.mitra_detail',compute='_compute_partner_id', string="MIP")
    partner_id = fields.Many2one(comodel_name='res.partner', string='Nama Mitra', required=True, tracking=True)
    rm_name_id = fields.Many2one(comodel_name='res.users', string='Nama Pengaju', required=True, tracking=True, default=lambda self: self.default_pengaju())
    assignee_id = fields.Many2one(comodel_name='res.users', string='Nama PD', required=True, tracking=True, default=lambda self: self.default_pd())
    proposal_ids = fields.One2many(comodel_name='cnt_pm.proposal', inverse_name='mip_id',required=True, tracking=True, string='Perihal Program')
    total_donasi = fields.Float(size=15, digits=(15, 0), default=0, compute="_compute_total_donasi", tracking=True, store=True)
    body = fields.Html(string="Message Body")
    status = fields.Selection([
        ('1_open', 'Open'),
        ('2_staffreplied', 'Staff Replied'),
        ('3_process', 'Process'),
        ('4_needreview', 'Need Review'),
        ('5_closed', 'Closed'),
        ('6_pending', 'Pending')
    ], default="1_open", string='Status', compute="_compute_status", store=True, tracking=True)
    deadline = fields.Date(string="Due Date", required=True, tracking=True)

    plan_lokasi =fields.Char(string='Lokasi project', tracking=True)
    donation_prediction = fields.Char('Perkiraan donasi', tracking=True)
    cover_title = fields.Char('field_name')
    note = fields.Char('field_name', tracking=True)
    note_file = fields.Char('field_name', tracking=True)
    attachment = fields.Binary()
    attachment_filename = fields.Char(string="Attachment Filename")

    telah_dikirim_notif = fields.Boolean()

    def copy(self, default=None):
        if default is None:
            default = {}
    
    
        # Duplicate the related records in the one-to-many field
        duplicated_one2many = [(0, 0, rec.copy_data()[0]) for rec in self.proposal_ids]

        # Update the default values with the duplicated one-to-many field
        default['proposal_ids'] = duplicated_one2many

        return super(MIP, self).copy(default)
    
    # untuk jumlah donasi
    @api.depends('proposal_ids')
    def _compute_total_donasi(self):
        total_donasi = sum(record.donation_prediction for record in self.proposal_ids)
        self.total_donasi = total_donasi

    # untuk order by status di mode tree
    @api.depends('status')
    def _compute_status_order(self):
        for record in self:
            if record.status == '1_open':
                record.status_order = 1
            elif record.status == '3_process':
                record.status_order = 2
            elif record.status == '5_closed':
                record.status_order = 3
    
    status_order = fields.Integer(
        string='Status Order',
        compute='_compute_status_order',
        store=True,
    )

    # ini buat status di mode tree 
    @api.depends('proposal_ids.status_proposal')
    def _compute_status(self):
            for mip in self:
        
                status_proposals = mip.proposal_ids.mapped('status_proposal')
                if all(status == '1_open' for status in status_proposals):
                    mip.status = '1_open'
                elif all(status == '4_closed' for status in status_proposals):
                    mip.status = '5_closed'
                else:
                    mip.status = "3_process"

    # agar nama pengaju oromatis terisi berdasarkan yang login
    def default_pengaju(self):
        pengaju = self.env['res.users'].search([('user_ids.id', '=', self.env.user.id)])
        return pengaju
    
    def default_pd(self):
        rm = self.env['cnt_pm.relasi'].search([('rm_id.id', '=', self.env.user.id)])
        print('INI RM nya ada',rm,'INI PD NYA ADA',rm.pd_id.id)
        return rm.pd_id.id
    
    # ini untuk mendefinisikan send di notif (api.model)
    def send (self, message, urls):
        urllib.parse.quote(message)
        url = "https://api.telegram.org/bot" + str(urls.api_key) + "/sendMessage?text=" + \
                message+"&chat_id="
        if urls.chat_id != False:
            try:
                requests.get(url + urls.chat_id)
            except requests.exceptions.ReadTimeout:
                print("TIMEOUT")
            pass

    @api.model
    def create(self, vals):
        # ini buat create nomor MIP
        current_year = datetime.datetime.now().strftime("%Y")
        current_month = datetime.datetime.now().strftime("%m")
        month_mapping = {
            "01": "I",
            "02": "II",
            "03": "III",
            "04": "IV",
            "05": "V",
            "06": "VI",
            "07": "VII",
            "08": "VIII",
            "09": "IX",
            "10": "X",
            "11": "XI",
            "12": "XII",
        }
        current_month_roman = month_mapping[current_month]

        if not vals.get('nomor_mip'):
            nomor_mip = 'MIP'
            code_count = self.env['cnt_pm.mip'].search_count([('nomor_mip', 'like', nomor_mip + '%')])
            if code_count > 0:
                last_mip = self.env['cnt_pm.mip'].search([('nomor_mip', 'like', nomor_mip + '%')], order="id desc", limit=1)
                last_mip_number = int(last_mip.nomor_mip.split('.P')[-1].split('.')[0])
                nomor_mip += '.P' + str(last_mip_number + 1) + '.' + str(current_month_roman) + '.' + str(current_year)
            else:
                nomor_mip += '.P1.' + str(current_month_roman) + '.' + str(current_year)
            vals['nomor_mip'] = nomor_mip

        mip = super(MIP, self).create(vals)

        # buat notifikasi telegram
        notif  = self.env['cnt_pm.mip'].search([('id', '=', mip.id)])
        current_user = self.env['res.users'].browse(self._uid)
        urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
        template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'mip_create_notif')])
        if urls.notif_via == 'telegram':
            message = template_telegram.template_content
            message = message.replace('<partner_id>', str(notif.partner_id.name))
            message = message.replace('<name_mip>', str(notif.name_mip))
            message = message.replace('<rm_name_id>', str(notif.rm_name_id.name))
            message = message.replace('<assignee_id>', str(notif.assignee_id.name))
            message = message.replace('<created_by>', str(current_user.name))
            message = message.replace('<id_mip>', str(mip.id))
            self.send(message, urls)

        return mip

    # action reply
    def action_reply(self):
        self.ensure_one()
        return {
            'name': 'Reply Message',
            'type': 'ir.actions.act_window',
            'res_model': 'cnt_pm.reply',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
            'context': {
                'default_model': 'cnt_pm.mip',
                'default_res_id': self.id,
                ' default_field': 'description',
            },
        }
    
    # def kanban_color(self, status):
    #     # Define the color mapping based on the status field
    #     color_mapping = {
    #         'open':'kanban-color-red',
    #         'needreview':'kanban-color-blue',
    #         'staffreplied':'kanban-color-yellow',
    #         'closed':'kanban-color-green',
    #         'pending':'kanban-color-orange'
    #     }
    #     return color_mapping.get(status, '')

    def pending_buttons(self):
        self.status = 'pending'
    
    def close_buttons(self):
        self.status = 'needreview'

    def approve_buttons(self):
        self.status = 'closed'

    
    def write(self, values):
        try :
            ticket_msg = self.env['cnt_pm.mip'].search([('id', '=', self.id)])
            data = {}
            for key in values:
                if key != 'attachment':
                    data[key] = {
                        'before': str(ticket_msg[key]),
                        "after" : str(values[key])
                    }
                else:
                    data[key] = {
                        'before' : 'Attachment Not Available On Log',
                        'after' : 'Attachment Not Available On Log'
                    }
            log = {
                'activity' : 'Edit',
                'record_id' : self.id,
                'record_name' : ticket_msg.rm_name_id,
                'menu' : 'gawean.ticket',
                'data' : json.dumps(data, indent = 4),
                'field_count': len(values),
            }
        except:
            pass

        if 'rm_name_id' in values:
            if values['rm_name_id']:
                values['rm_name_id'] = values['rm_name_id'].lower()
        res = super(MIP, self).write(values)
        
        try :
            if self.id != 0:
                self.env['cnt_pm.log'].create(log)
        except :
            pass
        return res


    # @api.constrains('nomor_mip')
    # def send_notif_tele(self):
    #     if self.status == 'open' and self.nomor_mip and not self.telah_dikirim_notif:
    #         try:
    #             message = "Request Program" + '\n' + "Tanggal Ajuan : " + str(self.create_date) + '\n' + "Nama RM : " + str(self.rm_name_id.name) + '\n' + "Assignee : " + str(self.assignee_id.name) + '\n\n'
                
    #             for proposal in self.proposal_ids:
    #                 message += "Nama Program : " + str(proposal.cover_title) + '\n'
    #                 message += "Nama Mitra : " + str(proposal.partner_id.name) + '\n'
    #                 message += "Lokasi : " + str(proposal.plan_lokasi) + '\n'
    #                 message += "Perkiraan Donasi : " + str(proposal.donation_prediction) + '\n\n'
                    
    #                 message += "Dokumen Request:" + '\n'
                    
    #                 for dokumen in proposal.dokumenproposal_ids:
    #                     message += "> " + str(dokumen.jenis_dokumen) + '\n'
    #                     message += "    Deadline : " + str(dokumen.deadline) + '\n'
    #                     message += "    Catatan : " + str(dokumen.note) + '\n'
    #                     message += "    Status : " + str(dokumen.status) + '\n'
                
    #             message = urllib.parse.quote(message) 
    #             boturl = "https://api.telegram.org/bot6067674764:AAHHbey_xhuFL_bS4jAupElYr8kURLLznmo/sendMessage?text=" + str(message) + "&chat_id=" + str(self.assignee_id.mobile)
    #             boturla = "https://api.telegram.org/bot6067674764:AAHHbey_xhuFL_bS4jAupElYr8kURLLznmo/sendMessage?text=" + str(message) + "&chat_id=" + str(self.rm_name_id.mobile)
    #             requests.get(boturl)
    #             requests.get(boturla)
    #         except:
    #             print("Something went wrong")



    
    @api.constrains('nomor_mip')
    def send_tele_need_review(self):
        if self.status == 'staffreplied' and self.nomor_mip:
            print('BISA BISA')
            for record in self:
                try:
                    if self.telah_dikirim_notif == False:
                        message = "Ada Memo Internal Project baru dari mitra "
                        message = urllib.parse.quote(message) 
                        boturl = "https://api.telegram.org/bot6067674764:AAHHbey_xhuFL_bS4jAupElYr8kURLLznmo/sendMessage?text=" + str(message) + "&chat_id=" + str(record.rm_name_id.mobile)
                        boturla = "https://api.telegram.org/bot6067674764:AAHHbey_xhuFL_bS4jAupElYr8kURLLznmo/sendMessage?text=" + str(message) + '111' + "&chat_id=" + str(record.assignee_id.mobile)
                        print('INI ID TELE',record.rm_name_id.mobile)
                        requests.get(boturl)
                        requests.get(boturla)
                    else:
                        print('gak bisa')
                except:
                            print("Something else went wrong") 

    # @api.constrains('proposal_ids')
    # def _check_proposal_ids(self):
    #     print("CHECK HEULA", self.proposal_ids)
    #     if len(self.proposal_ids) < 1:
    #         print("TESTING R",self.proposal_ids)
    #         raise ValidationError("Proposal minimal harus ada 1 (satu)")

    #Compute_partner_id
    @api.depends ('partner_id') 
    def _compute_partner_id(self):
        for record in self:
            if record.partner_id:
                mitra_biodata = self.env["cnt_trial.mitra_detail"].search([("partner_id", '=', record.partner_id.id)],limit=1) 
                record.mitra_id = mitra_biodata 
                print(mitra_biodata)
            # return mitra_biodata
