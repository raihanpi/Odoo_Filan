from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
import requests

class Donasi(models.Model):
  _name = 'cnt_pm.donasi'
  _description = 'Tahap donasi dan Rincian Project'
  _rec_name = 'mipro_id'

  mipro_id = fields.Many2one('cnt_pm.mipro')
  donasi = fields.Text(string='Donasi')
  persentase = fields.Char(string='Persentase DP')
  tahap_donasi = fields.Char( string='Tahap Donasi', default="Tahap Ke ")
  nominal_donasi = fields.Float('Nominal Donasi', size=15, digits=(15, 0), store=True)
  ket_donasi = fields.Text('Keterangan')
