import urllib.parse
import xml
from odoo import fields, models, api
import datetime
from odoo.exceptions import ValidationError
import requests
import json
import pathlib

class Reply(models.Model):
    _name = 'cnt_pm.reply'
    _description = 'Reply'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    partner_id = fields.Many2one(
        'res.partner', string="Partner", readonly=True)
    email = fields.Many2one(comodel_name='res.users', default=lambda self: self.default_user())
    note = fields.Html(string="Message note")
    log_note = fields.Html(string='Log Note')
    body = fields.Html(string='Note')

    
    def default_user(self):
        user = self.env['res.users'].search([('user_ids.id', '=', self.env.user.id)])
        return user

    # message = fields.Html(string='Message')
    # mip_id = fields.Many2one('cnt_pm.mip', string='MIP')
    # message_proposal =fields.Html(string='Message')
    # proposal_id = fields.Many2one('cnt_pm.proposal', string='PROPOSAL')

    # def reply_action(self):
    #     # Perform actions with the entered message, e.g., log or send it
    #     self.ensure_one()
    #     self.mip_id.message_post(body=self.message)
    #     self.mip_id.status = 'staffreplied'
    #     return {'type': 'ir.actions.act_window_close'}
    
    # def reply_action_proposal(self):
    #     # Perform actions with the entered message, e.g., log or send it
    #     self.ensure_one()
    #     self.proposal_id.message_post(body=self.message_proposal)
    #     self.proposal_id.status_proposal = 'staffreplied'
    #     return {'type': 'ir.actions.act_window_close'}

    message = fields.Html(string='Message', required=True)
    model = fields.Char(string='Model')
    res_id = fields.Integer(string='Record ID')
    field = fields.Char(string='Field')

    # API Telegram
    def send (self, message, urls):
        urllib.parse.quote(message)
        url = "https://api.telegram.org/bot" + str(urls.api_key) + "/sendMessage?text=" + \
                message+"&chat_id="
        if urls.chat_id != False:
            try:
                requests.get(url + urls.chat_id)
            except requests.exceptions.ReadTimeout:
                print("TIMEOUT")
            pass

    def reply_action(self):
        self.ensure_one()
        model = self.model
        res_id = self.res_id
        field = self.field
        record = self.env[model].browse(res_id)
        record[field] = self.message

        # Create a log message in the chatter
        log_message = self.env['cnt_pm.log'].create({
            'message': self.message,
            'model': model,
            'res_id': res_id,
            'mip_id': res_id if model == 'cnt_pm.mip' else False,
            'proposal_id': res_id if model == 'cnt_pm.proposal' else False,
            'mipro_id': res_id if model == 'cnt_pm.mipro' else False,
            'mil_id': res_id if model == 'cnt_pm.mil' else False,
            'spp_id': res_id if model == 'cnt_pm.spp' else False,
        })

        # Update the status if the message is sent
        if model == 'cnt_pm.mip':
            mip_record = self.env[model].browse(res_id)
            mip_record.status = 'staffreplied'
            record.message_post(body=self.message)
        elif model == 'cnt_pm.proposal':
            proposal_record = self.env[model].browse(res_id)
            proposal_record.status_proposal = '2_staffreplied'
            record.message_post(body=self.message)
            urls = self.env['cnt_pm.notif_account'].search([('active', '=', True)])
            template_telegram = self.env['cnt_pm.template'].search([('id_template', '=', 'proposal_reply_notif')])
            current_user = self.env['res.users'].browse(self._uid)
            if urls.notif_via == 'telegram':
                message = template_telegram.template_content
                message = message.replace('<name_program>', str(proposal_record.cover_title))
                message = message.replace('<partner_id>', str(proposal_record.partner_id.name))
                message = message.replace('<rm_name_id>', str(proposal_record.rm_name_id.name))
                message = message.replace('<current_user>', str(current_user.name))
                message = message.replace('<file>', str(proposal_record.rab_all))
                message = message.replace('<id_proposal>', str(proposal_record.id))
                message = message.replace('<id_pd>', str(proposal_record.assignee_id.name))
                message = message.replace('<body_message>', str(self.message))
                message = message.replace('<p>', '')
                message = message.replace('</p>', '')

                self.send(message, urls)
        elif model == 'cnt_pm.mil':
            mil_record = self.env[model].browse(res_id)
            mil_record.status_mil = '2_staffreplied'
            record.message_post(body=self.message)
        elif model == 'cnt_pm.mipro':
            mipro_record = self.env[model].browse(res_id)
            mipro_record.state = '2_staffreplied'
            record.message_post(body=self.message)
        elif model == 'cnt_pm.spp':
            spp_record = self.env[model].browse(res_id)
            spp_record.status_spp = 'staffreplied'
            record.message_post(body=self.message)
        
        return {'type': 'ir.actions.act_window_close'}

