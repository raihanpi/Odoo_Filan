from odoo import api, fields, models
from odoo.exceptions import ValidationError

class Users(models.Model):
    _name = 'cnt_pm.users'
    _description = 'cnt_pm Users'
    _rec_name = 'name'

    name = fields.Char(string='Name')
    email = fields.Char(string='Email')
    password = fields.Char(string='Password')
    

    # @api.model
    # def create(self, values):
    #     res = super(Users, self).create(values)
    #     print(res.id)
    #     if res.id:
    #         user = self.env['res.users'].search([('id', '=', res.id)])
    #         print(user,'test')
    #         print(self.role)
    #         if res.role == 'Administrator':
    #             user.sudo().write({'groups_id': [(4,self.env.ref('cnt_pm.group_admin_cnt_pm').id)]})
    #             print("MSUKKKK")
    #         if res.role == 'RM':
    #             user.sudo().write({'groups_id': [(4,self.env.ref('cnt_pm.group_rm').id)]})
    #         if res.role == 'PIManager':
    #             user.sudo().write({'groups_id': [(4,self.env.ref('cnt_pm.group_pi_manager').id)]})
    #         if res.role == 'PIOfficer':
    #             user.sudo().write({'groups_id': [(4,self.env.ref('cnt_pm.group_pi_officer').id)]})
    #     return res

    # @api.model
    # def create(self, values):
    #     res = super(Users, self).create(values)
    #     try:
    #         data = {
    #             'name': values['name'],
    #             'login': values['email'],
    #             'password': values['password'],
    #             'role': values['state'],
    #         }
    #         self.env['res.users'].create(data)    
    #     except:
    #         pass
    #         return res