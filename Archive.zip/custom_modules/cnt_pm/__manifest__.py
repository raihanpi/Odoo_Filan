# -*- coding: utf-8 -*-
{
    'name': "CNT Project Management",

    'summary': """
        CNT Project Management""",

    'description': """
        CNT Project Management
    """,

    'author': "Firyal",
    'website': "https://erp16-filantra-dev1.cnt.id/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly

    # always loaded
    'data': [
        'security/access_group.xml',
        'security/ir.model.access.csv',
        'views/admin/relasi_admin.xml',
        'views/admin/mip_admin.xml',
        'views/admin/proposal_admin.xml',
        'views/admin/mipro_admin.xml',
        'views/admin/spp_admin.xml',
        'views/admin/mil_admin.xml',
        'views/admin/pi_admin.xml',
        'views/admin/rab_admin.xml',
        'views/admin/users_admin.xml',
        'views/admin/provinsi_admin.xml',
        'views/admin/kota_admin.xml',
        'views/admin/kecamatan_admin.xml',
        'views/admin/desa_admin.xml',
        'views/admin/template_admin.xml',
        'views/admin/notif_account_admin.xml',
        'views/admin/informasi_rekening_admin.xml',
        'views/menu.xml',
        'report/mipro_report.xml',
        'report/mipro_template.xml',
        'report/proposal.xml',
        'report/spp_report.xml',
        'report/spp_template.xml',

        'views/pm/mipro_admin.xml',
        'views/rm/mip_admin.xml',
        'views/rm/proposal_admin.xml', 
        'views/pm/spp_admin.xml', 

    ],
    'assets': {

        'web.assets_backend': [
            'cnt_pm/static/src/scss/theme.scss',

        ],
    },
    # # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'qweb': [
        'view/xml/change_menu.xml'
    ],
    'depends': ['mail', 'base', 'sale', 'account', 'product'],
    'installable': True,
    'auto_install': False,
    'application': True,
}
