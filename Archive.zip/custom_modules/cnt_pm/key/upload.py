from pydrive.drive import GoogleDrive
from pydrive.auth import GoogleAuth
import base64
import tempfile
import requests
import json


def getFolderID(name):
    folders = drive.ListFile(
        {'q': "title='" + folderName + "' and mimeType='application/vnd.google-apps.folder' and trashed=false"}).GetList()
    for folder in folders:
        if folder['title'] == name:
            return folder['id']


def uploadImage(string, metadata):
    files = {
        'data': ('metadata', json.dumps(metadata), 'application/json'),
        'file': base64.b64decode(
            string),
    }
    r = requests.post(
        "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
        headers={"Authorization": "Bearer " + gauth.credentials.access_token},
        files=files
    )
    return r.json()

# Below code does the authentication
# part of the code
gauth = GoogleAuth()

gauth.access_type = 'offline'
# Try to load saved client credentials
gauth.LoadCredentialsFile("mycreds.txt")
print(gauth.credentials)
if gauth.credentials is None:
    # Authenticate if they're not there
    gauth.LocalWebserverAuth()
elif gauth.access_token_expired:
    # Refresh them if expired
    gauth.Refresh()
else:
    # Initialize the saved creds
    gauth.Authorize()
gauth.SaveCredentialsFile("mycreds.txt")

# Creates local webserver and auto
# handles authentication.
drive = GoogleDrive(gauth)

# replace the value of this variable
# with the absolute path of the directory
path = r"./1.doc"
folderName = "filantra"  # Please set the folder name.
file = open(path).read()


metadata = {
    "name": "coba3.jpg",
    "parents": [getFolderID(folderName)]
}
# parent_folder_id = '0AHj7UpiS-tNIUk9PVA'

# f = drive.CreateFile({
#     'parents': [{
#         'kind': 'drive#fileLink',
#         'teamDriveId': '0AHj7UpiS-tNIUk9PVA',
#         'id': parent_folder_id
#     }]
# })
# f.SetContentFile(path)
# f.Upload(param={'supportsTeamDrives': True})
uploadImage(file, metadata)